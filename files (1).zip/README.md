# Pocket Training

A climbing training calendar and performance tracker: plan a 12-week cycle, log sessions and check-ins, and track tests, goals and body measurements.

It's a static site with no build step and no dependencies. Open `index.html` in a browser, serve the folder with any static file server, or publish it with GitHub Pages.

## Pages

- **Dashboard**: today's sessions, a readiness check-in, weekly load against plan, what's next, goals, recent tests and a send pyramid.
- **Planner**: the 12-week cycle by phase, a week view where you add, log or skip sessions, and phase templates that fill the remaining days of a week.
- **Workouts**: a library of training sessions with blocks (sets, reps, work, rest, load). Edit, duplicate, delete or add to the plan.
- **Metrics**: acute load and acute:chronic ratio, weekly load by phase or type, a consistency heatmap, finger strength, body composition, wellness trends, and a correlation view for any two signals.
- **Goals**: grade, strength, volume and habit goals with expected-pace tracking and milestones. Strength goals can update automatically from a linked test.
- **Tests**: benchmark protocols with results history, retest reminders and scheduling.

## Dates

The cycle runs Monday, August 17 to Sunday, November 8, 2026. "Today" follows the real date and stays inside that window: before the cycle it shows the first day, after it the last. The cycle start and length are set at the top of `app.js`.

## Accounts

Click the profile at the bottom of the sidebar (or the avatar on a phone) to open **Who's training?**:

- **Switch** between people. Each person has their own sessions, plan, workouts, goals, tests, check-ins and body measurements.
- **Add person** with a name, coaching note, home crag and bodyweight. Start from a blank slate (workout library and test protocols, no history) or a copy of the sample cycle.
- **Edit active profile** to rename or update details. Delete is available when more than one account exists; it asks you to click twice.

Accounts are local profiles, not secure logins: anyone using the same browser can switch between them.

## Storage

Everything is saved in the browser's localStorage:

- `pocket-training-accounts`: the account list and the active account.
- `pocket-training-v1:<accountId>`: one training dataset per person.

Data saved by the earlier build is converted to the current format the first time it loads, including the single-user key `pocket-training-v1`, which becomes the first account (Avery Lane). Clear these keys to restore the sample cycle.

## Files

- `index.html`: page shell and font loading (Archivo and JetBrains Mono from Google Fonts).
- `styles.css`: the "Sandstone Day" design: warm paper, rust and forest accents, topo-line hero. Layouts adapt from desktop to tablet to phone.
- `app.js`: data, storage, accounts, page rendering and interactions.

## Publish with GitHub Pages

In the repository settings, open **Pages**, set the source to **Deploy from a branch**, and choose the branch and the folder that contains `index.html`.
