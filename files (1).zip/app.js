(() => {
  "use strict";

  /* =========================================================
     Calendar
     The 12-week cycle runs Monday Aug 17 – Sunday Nov 8, 2026.
     "Today" follows the real date, held inside that window.
     ========================================================= */
  const NW = 12, DAYS = NW * 7;
  const CYCLE_NAME = "Fall send cycle";
  const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const MONTH = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const DOW = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const WEEKDAY = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const dt = d => new Date(2026, 7, 17 + d);
  const off = (m, d) => Math.round((new Date(2026, m, d) - new Date(2026, 7, 17)) / 864e5);
  const TODAY = (() => {
    const n = new Date();
    return clamp(Math.round((new Date(n.getFullYear(), n.getMonth(), n.getDate()) - new Date(2026, 7, 17)) / 864e5), 0, DAYS - 1);
  })();
  const CW = Math.floor(TODAY / 7);
  const dow = d => ((d % 7) + 7) % 7;
  const sd = d => { const x = dt(d); return MON[x.getMonth()] + " " + x.getDate(); };
  const ld = d => DOW[dow(d)] + " " + sd(d);
  const fullDate = d => { const x = dt(d); return WEEKDAY[dow(d)] + ", " + MONTH[x.getMonth()] + " " + x.getDate(); };
  const iso = d => { const x = dt(d); return x.getFullYear() + "-" + String(x.getMonth() + 1).padStart(2, "0") + "-" + String(x.getDate()).padStart(2, "0"); };
  const fromIso = v => {
    const p = String(v).split("-").map(Number);
    if (p.length < 3 || p.some(isNaN)) return TODAY;
    return Math.round((new Date(p[0], p[1] - 1, p[2]) - new Date(2026, 7, 17)) / 864e5);
  };
  const fmtN = n => Math.round(n).toLocaleString("en-US");
  const clone = o => JSON.parse(JSON.stringify(o));
  const clockNow = () => {
    const n = new Date(), h = n.getHours();
    return ((h % 12) || 12) + ":" + String(n.getMinutes()).padStart(2, "0") + (h < 12 ? "am" : "pm");
  };

  /* =========================================================
     Training vocabulary (from the approved design)
     ========================================================= */
  const YDS = ["5.10a", "5.10b", "5.10c", "5.10d", "5.11a", "5.11b", "5.11c", "5.11d", "5.12a", "5.12b", "5.12c", "5.12d", "5.13a", "5.13b", "5.13c", "5.13d", "5.14a"];
  const VG = [...Array(13)].map((_, i) => "V" + i);
  const TC = { Fingers: "#C08A28", Board: "#B5502A", Bouldering: "#8E3B2A", Sport: "#3E5A73", Trad: "#5E7A8C", Strength: "#6E7F3A", Cardio: "#3F6B4F", Mobility: "#8A7A6B" };
  const TYPES = Object.keys(TC);
  const PH = {
    Base: { c: "#3F6B4F", f: "Aerobic capacity, finger volume and movement mileage. Keep intensity moderate." },
    Strength: { c: "#C08A28", f: "Max finger strength and heavy pulling. Low volume, full rest between efforts." },
    Power: { c: "#B5502A", f: "Recruitment and speed: board limit problems, campus ladders, short max hangs." },
    "Power Endurance": { c: "#8E3B2A", f: "Sustained hard efforts: 4×4s, linked boulders, route intervals." },
    Perform: { c: "#3E5A73", f: "Cut gym volume and spend the energy on outdoor redpoint burns." }
  };
  const PHN = Object.keys(PH);
  const INITIAL_PHASES = ["Base", "Base", "Base", "Strength", "Strength", "Strength", "Power", "Power", "Power Endurance", "Power Endurance", "Perform", "Perform"];
  const TPL = {
    Base: [[0, "w10"], [0, "w4"], [1, "w11"], [2, "w5"], [3, "w3"], [4, "w6"], [5, "w7"], [6, "w8"]],
    Strength: [[0, "w3"], [1, "w4"], [1, "w5"], [3, "w1"], [3, "w12"], [4, "w6"], [5, "w7"], [6, "w8"]],
    Power: [[0, "w3"], [1, "w4"], [1, "w5"], [2, "w6"], [4, "w1"], [4, "w2"], [5, "w7"], [6, "w8"]],
    "Power Endurance": [[0, "w9"], [1, "w4"], [2, "w5"], [3, "w2"], [4, "w11"], [5, "w7"], [6, "w7"]],
    Perform: [[1, "w9"], [2, "w6"], [3, "w1"], [5, "w7"], [6, "w7"]]
  };
  const GOAL_CC = { Grade: "#B5502A", Strength: "#C08A28", Volume: "#3E5A73", Habit: "#3F6B4F" };
  const TEST_CATS = ["Finger strength", "Pulling", "Core", "Endurance", "Power", "Mobility", "Body comp"];
  const PYRAMID0 = [["5.12d", 1], ["5.12c", 2], ["5.12b", 4], ["5.12a", 7], ["5.11d", 11], ["V7", 1], ["V6", 3]];
  const B = (name, sets, reps, work, rest, load) => ({ name, sets, reps, work, rest, load });

  /* ---------- Sample cycle (Avery Lane, Red River Gorge) ---------- */
const W0=[
{id:'w1',name:'Max Hangs',type:'Fingers',dur:50,rpe:8,desc:'Half-crimp on a 20 mm edge. Load so the last hang of each set is hard but clean.',blocks:[B('Warm-up ramp','4','1','10 s','60 s','BW → +10 kg'),B('Max hangs, 20 mm half-crimp','6','1','7 s','3 min','+18 kg'),B('Open-hand drag, 20 mm','3','1','7 s','3 min','+10 kg')]},
{id:'w2',name:'Board — 40° Power',type:'Board',dur:60,rpe:8,desc:'Short, powerful problems on the 40° board. Full rest between attempts.',blocks:[B('Warm-up circuit','1','6 problems','—','1 min','V2–V4'),B('Limit problems','5','3 attempts','—','3 min','V6–V7'),B('Campus ladders','4','1','1-4-7','3 min','BW')]},
{id:'w3',name:'Limit Bouldering',type:'Bouldering',dur:90,rpe:9,desc:'Two to three problems at your limit. Quality attempts only; stop when movement degrades.',blocks:[B('Warm-up pyramid','1','8 problems','—','1 min','V0–V5'),B('Limit projects','6','4 attempts','—','4 min','V7–V8')]},
{id:'w4',name:'Pull & Antagonist',type:'Strength',dur:55,rpe:7,desc:'Heavy pulling paired with pushing and wrist work for shoulder and elbow health.',blocks:[B('Weighted pull-ups','5','3','—','3 min','+34 kg'),B('Ring dips','3','8','—','2 min','BW'),B('Overhead press','3','6','—','2 min','16 kg KB'),B('Wrist extensors','3','15','—','1 min','4 kg')]},
{id:'w5',name:'Easy Run',type:'Cardio',dur:40,rpe:4,desc:'Conversational pace. Builds aerobic base and long approach fitness.',blocks:[B('Zone 2 run','1','1','40 min','—','6 km · HR < 145')]},
{id:'w6',name:'Mobility Flow',type:'Mobility',dur:30,rpe:3,desc:'Hips for high steps and drop knees, shoulders for overhangs.',blocks:[B('Hip openers','2','5 / side','45 s','—','—'),B('Shoulder CARs','2','5','—','—','—'),B('Pancake & pike','3','1','60 s','30 s','—')]},
{id:'w7',name:'Gorge Day — Project',type:'Sport',dur:240,rpe:7,desc:'Outdoor redpoint day. Two warm-ups, then three quality burns on the project.',blocks:[B('Warm-up routes','2','1','—','15 min','5.10–5.11'),B('Project burns','3','1','—','30–40 min','5.12d–5.13a'),B('Cooldown lap','1','1','—','—','5.10')]},
{id:'w8',name:'Trad Mileage',type:'Trad',dur:240,rpe:6,desc:'Moderate cracks and multi-pitch for gear placement practice and volume.',blocks:[B('Pitches','5','1','—','—','5.9–5.10')]},
{id:'w9',name:'4×4 Circuits',type:'Bouldering',dur:60,rpe:9,desc:'Four problems back to back, four times. Pick problems 3–4 grades below max.',blocks:[B('Warm-up','1','6 problems','—','—','V2–V4'),B('4×4 sets','4','4 problems','—','4 min','V4–V5')]},
{id:'w10',name:'Repeaters 7:3',type:'Fingers',dur:40,rpe:7,desc:'Finger endurance on a 20 mm edge at bodyweight.',blocks:[B('Repeaters, 20 mm','6','6 reps','7 s on / 3 s off','3 min','BW')]},
{id:'w11',name:'ARC Traverse',type:'Sport',dur:45,rpe:5,desc:'Continuous easy climbing with a light, sustainable pump.',blocks:[B('Continuous traversing','3','1','12 min','4 min','Light pump')]},
{id:'w12',name:'Core & Legs',type:'Strength',dur:45,rpe:6,desc:'Body tension for steep Gorge pockets and roofs.',blocks:[B('Front lever progressions','5','1','max hold','2 min','Adv. tuck'),B('Hanging leg raises','3','10','—','90 s','BW'),B('Bulgarian split squat','3','8','—','90 s','20 kg')]}
];
const SPORT=['Motherlode','Muir Valley','PMRP','Military Wall','Drive-By Crag','Torrent Falls'];
const TRAD=['Fortress Wall','Military Wall'];
const H=(a)=>a.map(([m,d,v,note])=>({d:off(m,d),v,note:note||''}));
const T0=[
{id:'t1',name:'Max hang · 20 mm',cat:'Finger strength',unit:'kg',better:'higher',freq:4,equip:'20 mm edge, harness and plates',steps:['Warm up 15 min, including three ramp-up hangs.','Half-crimp, 7 s hang on the 20 mm edge.','Add load each attempt; rest 3 min between.','Record the heaviest clean 7 s hang. Max five attempts.'],hist:H([[0,10,10],[1,14,11],[2,21,12],[4,2,12.5],[5,13,14],[7,1,15],[7,29,16],[8,28,18,'Felt strong, slept 8 h']])},
{id:'t2',name:'Weighted pull-up · 1RM',cat:'Pulling',unit:'kg',better:'higher',freq:6,equip:'Pull-up bar, dip belt',steps:['Two sets of 5 at bodyweight, then three ramp sets.','Start from a dead hang; chin clears the bar.','Add 2–5 kg per attempt with 3–4 min rest.','Record the heaviest clean rep.'],hist:H([[0,17,28],[2,7,30],[3,25,31],[5,20,33],[7,15,34],[8,30,38]])},
{id:'t3',name:'Front lever hold',cat:'Core',unit:'s',better:'higher',freq:4,equip:'Pull-up bar or rings',steps:['Warm up core and scapular pulls.','Full front lever, body horizontal, arms straight.','Best of three attempts, 3 min rest.','Stop the clock when hips drop below the line.'],hist:H([[2,1,3],[3,20,3.5],[5,5,4],[7,10,4.5],[8,18,6]])},
{id:'t4',name:'Repeaters 7:3 to failure',cat:'Endurance',unit:'reps',better:'higher',freq:6,equip:'20 mm edge',steps:['Bodyweight, 20 mm half-crimp.','Hang 7 s, rest 3 s, repeat.','Count reps until you cannot complete a full 7 s hang.'],hist:H([[1,20,24],[4,9,28],[6,11,30],[8,12,33]])},
{id:'t5',name:'Pancake reach',cat:'Mobility',unit:'cm',better:'higher',freq:8,equip:'Floor, tape measure',steps:['Sit in a wide straddle, knees locked.','Fold forward and reach as far as possible.','Measure from hip line to fingertips. Best of three.'],hist:H([[0,25,18],[3,12,21],[5,28,22],[8,5,25]])}
];
const G0=[
{id:'g1',title:'Redpoint 5.13a',cat:'Grade',scale:'yds',start:9,target:12,cur:11,unit:'',startD:0,deadline:off(10,15),testId:'',note:'Fall project at the Motherlode. The Perform block lines up with late-October temps.',hist:[{d:0,v:9},{d:19,v:10},{d:40,v:11}],ms:[{t:'Send a 5.12c at the Gorge',done:true},{t:'Send a 5.12d',done:true},{t:'Link the project in two overlaps',done:false},{t:'One-hang the project',done:false},{t:'Redpoint',done:false}]},
{id:'g2',title:'Max hang +22 kg',cat:'Strength',scale:'',start:10,target:22,cur:18,unit:'kg',startD:off(0,10),deadline:off(11,31),testId:'t1',note:'20 mm half-crimp, 7 s. Roughly 130% bodyweight at current weight.',hist:[],ms:[{t:'+15 kg',done:true},{t:'+18 kg',done:true},{t:'+20 kg',done:false}]},
{id:'g3',title:'60 outdoor days',cat:'Volume',scale:'',start:0,target:60,cur:44,unit:'days',startD:off(0,1),deadline:off(11,31),testId:'',note:'Any day with at least three routes or two hours of climbing outside.',hist:[{d:off(0,1),v:0},{d:off(2,31),v:8},{d:off(4,31),v:19},{d:off(6,31),v:30},{d:42,v:44}],ms:[{t:'Spring season: 20 days',done:true},{t:'Fall season: 25 days',done:false}]},
{id:'g4',title:'Weighted pull-up +40 kg',cat:'Strength',scale:'',start:28,target:40,cur:38,unit:'kg',startD:off(0,17),deadline:off(11,31),testId:'t2',note:'Single rep, dead hang start.',hist:[],ms:[]},
{id:'g5',title:'Flash V6',cat:'Grade',scale:'v',start:4,target:6,cur:6,unit:'',startD:off(0,1),deadline:off(6,31),testId:'',note:'Outdoor flash, any area.',hist:[{d:off(0,1),v:4},{d:off(3,10),v:5},{d:off(5,22),v:6}],ms:[{t:'Flash V5',done:true},{t:'Flash V6',done:true}]}
];
const BODY0=[[0,15,72.4,13.8],[1,15,72.0,13.5],[2,15,71.8,13.3],[3,15,71.5,12.9],[4,15,71.2,12.6],[5,15,70.9,12.3],[6,15,70.6,12.0],[7,15,70.4,11.8],[8,30,70.1,11.6]].map(([m,d,w,bf])=>({d:off(m,d),w,bf}));

  /* =========================================================
     Derived numbers
     ========================================================= */
  const dayLoads = ses => { const a = Array(DAYS).fill(0); ses.forEach(x => { if (x.status === "done" && x.day >= 0 && x.day < a.length) a[x.day] += x.dur * x.rpe; }); return a; };
  const weekStats = (ses, w) => {
    let p = 0, d = 0, n = 0, nd = 0;
    ses.forEach(s => { if (Math.floor(s.day / 7) !== w) return; p += s.pdur * s.prpe; n++; if (s.status === "done") { d += s.dur * s.rpe; nd++; } });
    return { p, d, n, nd };
  };
  const ser = (arr, o = {}) => {
    if (!arr.length) return { pts: "", dots: [], lbl: [], from: "", to: "" };
    const ds = arr.map(a => a.d), vs = arr.map(a => a.v);
    const d0 = o.d0 ?? Math.min(...ds), d1 = o.d1 ?? Math.max(...ds);
    let lo = o.lo, hi = o.hi;
    if (lo == null) { lo = Math.min(...vs); hi = Math.max(...vs); const p = (hi - lo) * 0.18 || 1; lo -= p; hi += p; }
    if (hi === lo) { hi += 1; lo -= 1; }
    const X = d => d1 === d0 ? 50 : (d - d0) / (d1 - d0) * 100;
    const Y = v => clamp(100 - (v - lo) / (hi - lo) * 100, -5, 105);
    const dots = arr.map(a => ({ l: X(a.d).toFixed(2) + "%", t: Y(a.v).toFixed(2) + "%", lab: a.lab ?? sd(a.d), val: a.val ?? String(a.v) }));
    return { pts: arr.map(a => X(a.d).toFixed(2) + "," + Y(a.v).toFixed(2)).join(" "), dots, lbl: dots.filter((_, i) => i === 0 || i === dots.length - 1), from: sd(d0), to: sd(d1) };
  };
  const pear = (xs, ys) => {
    const n = xs.length; if (n < 3) return 0;
    const mx = xs.reduce((a, b) => a + b) / n, my = ys.reduce((a, b) => a + b) / n;
    let a = 0, b = 0, c = 0;
    for (let i = 0; i < n; i++) { a += (xs[i] - mx) * (ys[i] - my); b += (xs[i] - mx) ** 2; c += (ys[i] - my) ** 2; }
    return b && c ? a / Math.sqrt(b * c) : 0;
  };
  const gradeIndex = g => { const y = YDS.indexOf(g); if (y >= 0) return { v: false, i: y }; const v = VG.indexOf(g); return { v: true, i: v }; };
  const sortPyramid = list => list.slice().sort((a, b) => {
    const A = gradeIndex(a[0]), Bb = gradeIndex(b[0]);
    if (A.v !== Bb.v) return A.v ? 1 : -1;
    return Bb.i - A.i;
  });

  /* =========================================================
     Seed data
     ========================================================= */
  function seedState() {
    let seed = 11; const rnd = () => (seed = seed * 16807 % 2147483647) / 2147483647;
    const weekPhases = INITIAL_PHASES.slice();
    const sessions = []; let n = 1, si = 0, ti = 0;
    weekPhases.forEach((ph, w) => TPL[ph].forEach(([dw, wid]) => {
      const day = w * 7 + dw; const wk = W0.find(x => x.id === wid);
      const st = day < TODAY ? (rnd() < 0.09 ? "skipped" : "done") : "planned";
      const loc = wk.type === "Sport" && wid === "w7" ? SPORT[si++ % SPORT.length] : wk.type === "Trad" ? TRAD[ti++ % TRAD.length] : "";
      sessions.push({ id: "s" + n++, day, wid, name: wk.name, type: wk.type, pdur: wk.dur, prpe: wk.rpe, status: st,
        dur: st === "done" ? Math.round(wk.dur * (0.85 + rnd() * 0.3) / 5) * 5 : wk.dur,
        rpe: st === "done" ? clamp(wk.rpe + Math.round(rnd() * 2 - 1), 1, 10) : wk.rpe, loc, notes: "" });
    }));
    sessions.forEach(s => { if (s.day === 47) s.loc = "Motherlode"; if (s.day === 48) s.loc = "Fortress Wall"; });
    const load = dayLoads(sessions); const checkins = {};
    for (let d = 0; d <= TODAY; d++) {
      const sleep = Math.round((6 + rnd() * 2.5) * 2) / 2;
      const finger = clamp(Math.round(8.4 - (load[d - 1] || 0) / 480 + rnd() * 1.6 - 0.8), 3, 10);
      const mot = clamp(Math.round(5.4 + (sleep - 7) * 1.3 + rnd() * 2 - 1 + (finger - 7) * 0.4), 2, 10);
      checkins[d] = { mot, sleep, finger };
    }
    checkins[TODAY] = { mot: 8, sleep: 7.5, finger: 7, at: "7:12am" };
    return { sessions, workouts: clone(W0), checkins, body: clone(BODY0), tests: clone(T0), goals: clone(G0), weekPhases, pyramid: clone(PYRAMID0) };
  }
  // New people keep the workout library and test protocols, but start with no history.
  function blankState() {
    const d = seedState();
    return { sessions: [], workouts: d.workouts, checkins: {}, body: [], tests: d.tests.map(t => ({ ...t, hist: [] })), goals: [], weekPhases: INITIAL_PHASES.slice(), pyramid: [] };
  }

  /* =========================================================
     Storage and accounts
     pocket-training-accounts       account list + active account
     pocket-training-v1:<accountId> one dataset per person
     ========================================================= */
  const ACCOUNTS_KEY = "pocket-training-accounts";
  const DATA_PREFIX = "pocket-training-v1";
  const SCHEMA = 2;
  const DATA_KEYS = ["sessions", "workouts", "checkins", "body", "tests", "goals", "weekPhases", "pyramid"];
  const AVATARS = ["#C98F2E", "#7FA36B", "#D0896A", "#7E9CB3", "#BFA35E", "#A98DB0"];
  const dataKey = id => DATA_PREFIX + ":" + id;
  const storage = (() => { try { const s = window.localStorage; const k = "__pt"; s.setItem(k, "1"); s.removeItem(k); return s; } catch { return null; } })();
  const readJSON = k => { try { const v = storage && storage.getItem(k); return v ? JSON.parse(v) : null; } catch { return null; } };
  const writeJSON = (k, v) => { try { if (!storage) return false; storage.setItem(k, JSON.stringify(v)); return true; } catch { return false; } };

  // Data saved by the earlier Pocket Training build (schema 1) is converted on load.
  function migrateV1(d) {
    const base = blankState();
    const scaleOf = s => s === "V" ? "v" : s === "YDS" ? "yds" : "";
    return {
      sessions: (d.sessions || []).map(x => ({ id: x.id, day: x.day, wid: x.workoutId || "", name: x.name, type: x.type, pdur: x.plannedDuration ?? x.duration ?? 0, prpe: x.plannedRpe ?? x.rpe ?? 5, status: x.status || "planned", dur: x.duration ?? 0, rpe: x.rpe ?? 5, loc: x.location || "", notes: x.notes || "" })),
      workouts: Array.isArray(d.workouts) ? d.workouts : base.workouts,
      checkins: Object.fromEntries(Object.entries(d.checkins || {}).map(([k, c]) => [k, { mot: c.motivation, sleep: c.sleep, finger: c.fingers }])),
      body: (d.measurements || []).map(m => ({ d: m.day, w: m.weight, bf: m.bodyFat })),
      tests: (d.tests || []).map(t => ({ id: t.id, name: t.name, cat: t.category, unit: t.unit, better: String(t.direction || "Higher").toLowerCase(), freq: t.frequency || 4, equip: t.equipment || "", steps: t.steps || [], hist: (t.results || []).map(r => ({ d: r.day, v: r.value, note: r.note || "" })).sort((a, b) => a.d - b.d) })),
      goals: (d.goals || []).map(g => {
        const hist = [{ d: g.startDay ?? 0, v: g.start }];
        if (g.current !== g.start) hist.push({ d: Math.min(TODAY, g.deadline ?? TODAY), v: g.current });
        return { id: g.id, title: g.title, cat: g.category, scale: scaleOf(g.scale), start: g.start, target: g.target, cur: g.current, unit: g.unit || "", startD: g.startDay ?? 0, deadline: g.deadline ?? TODAY + 60, testId: g.testId || "", note: g.note || "", hist, ms: (g.milestones || []).map(m => ({ t: m.text, done: !!m.done })) };
      }),
      weekPhases: Array.isArray(d.phases) && d.phases.length === NW ? d.phases : base.weekPhases,
      pyramid: Array.isArray(d.pyramid) ? d.pyramid : []
    };
  }
  function normalize(d) {
    const base = blankState();
    const out = {};
    DATA_KEYS.forEach(k => { out[k] = d && d[k] != null ? d[k] : base[k]; });
    if (!Array.isArray(out.weekPhases) || out.weekPhases.length !== NW) out.weekPhases = base.weekPhases;
    return out;
  }
  function loadData(id) {
    const raw = readJSON(dataKey(id));
    if (raw && raw.version === SCHEMA && raw.data) return normalize(raw.data);
    if (raw && raw.version === 1 && raw.data) { try { return normalize(migrateV1(raw.data)); } catch { /* fall through */ } }
    return seedState();
  }
  function saveData(id, data) {
    const out = {}; DATA_KEYS.forEach(k => { out[k] = data[k]; });
    return writeJSON(dataKey(id), { version: SCHEMA, data: out });
  }
  function loadAccounts() {
    const saved = readJSON(ACCOUNTS_KEY);
    if (saved && saved.version === 1 && Array.isArray(saved.list) && saved.list.length) {
      if (!saved.list.some(a => a.id === saved.currentId)) saved.currentId = saved.list[0].id;
      return saved;
    }
    // First run, or an upgrade from the single-user build: that data becomes Avery's account.
    const first = { id: "a1", name: "Avery Lane", role: "Self-coached", home: "Red River Gorge", weight: 70.1, color: AVATARS[0] };
    const legacy = readJSON(DATA_PREFIX);
    if (legacy && !readJSON(dataKey(first.id))) writeJSON(dataKey(first.id), legacy);
    const created = { version: 1, currentId: first.id, list: [first] };
    writeJSON(ACCOUNTS_KEY, created);
    return created;
  }
  const saveAccounts = () => writeJSON(ACCOUNTS_KEY, accounts);
  const currentAccount = () => accounts.list.find(a => a.id === accounts.currentId) || accounts.list[0];
  const initials = name => { const p = String(name || "?").trim().split(/\s+/).filter(Boolean); return ((p[0]?.[0] || "?") + (p.length > 1 ? p[p.length - 1][0] : "")).toUpperCase(); };
  const firstName = name => String(name || "").trim().split(/\s+/)[0] || "climber";

  /* =========================================================
     State
     ========================================================= */
  const PAGES = ["dashboard", "planner", "workouts", "metrics", "goals", "tests"];
  const pageFromHash = () => { const h = (location.hash || "").slice(1); return PAGES.includes(h) ? h : null; };
  function uiFor(data, page) {
    const w0 = data.workouts[0];
    return {
      page: page || pageFromHash() || "dashboard", weekSel: CW,
      selWorkout: w0 ? w0.id : null, draft: w0 ? clone(w0) : null, wSearch: "", wType: "All", schedDay: String(Math.min(TODAY + 3, DAYS - 1)),
      selTest: data.tests[0] ? data.tests[0].id : null, testEdit: false, tDraft: null, logVal: "", logDate: iso(TODAY), logNote: "",
      selGoal: data.goals[0] ? data.goals[0].id : null, goalProg: "", newMs: "",
      modal: null, form: {}, armed: false,
      metRange: 28, loadMode: "total", corrX: "prev", corrY: "finger", bodyW: "", bodyBf: "", sendGrade: "5.12a"
    };
  }
  let accounts = loadAccounts();
  let S = { ...loadData(accounts.currentId) };
  Object.assign(S, uiFor(S));

  let saveTimer = 0;
  function persistNow() {
    clearTimeout(saveTimer); saveTimer = 0;
    if (!saveData(accounts.currentId, S) && storage) toast("Could not save changes in this browser");
  }
  // Write fresh or migrated datasets back in the current format straight away.
  function ensureCurrentFormat() { const raw = readJSON(dataKey(accounts.currentId)); if (!raw || raw.version !== SCHEMA) persistNow(); }
  const schedulePersist = () => { clearTimeout(saveTimer); saveTimer = setTimeout(persistNow, 250); };
  function set(patch) {
    const p = typeof patch === "function" ? patch(S) : patch;
    Object.assign(S, p);
    if (DATA_KEYS.some(k => k in p)) schedulePersist();
    render();
  }
  function setPath(path, value) {
    const keys = path.split(".");
    if (keys.length === 1) return set({ [path]: value });
    const top = clone(S[keys[0]]); let o = top;
    for (let i = 1; i < keys.length - 1; i++) o = o[keys[i]];
    o[keys[keys.length - 1]] = value;
    set({ [keys[0]]: top });
  }
  const setF = (k, v) => set(s => ({ form: { ...s.form, [k]: v } }));
  function toast(m) {
    const el = document.getElementById("toast"); if (!el) return;
    el.lastElementChild.textContent = m;
    el.classList.add("show");
    clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove("show"), 2400);
  }
  function go(p) {
    set({ page: p, modal: null });
    try { history.replaceState(null, "", "#" + p); } catch { /* sandboxed */ }
    window.scrollTo(0, 0);
  }

  /* =========================================================
     Actions
     ========================================================= */
  function openEdit(id, force) {
    const x = S.sessions.find(v => v.id === id); if (!x) return;
    set({ modal: "session", form: { mode: "edit", sid: id, wid: x.wid, day: String(x.day), dur: String(x.dur), rpe: String(x.rpe), loc: x.loc || "", notes: x.notes || "", status: force || x.status } });
  }
  function openNew(day, status) {
    const w = S.workouts[0];
    set({ modal: "session", form: { mode: "new", wid: w ? w.id : "", day: String(day), dur: String(w ? w.dur : 45), rpe: String(w ? w.rpe : 6), loc: "", notes: "", status } });
  }
  function openGoal(g) {
    set({ modal: "goal", form: g
      ? { mode: "edit", id: g.id, title: g.title, cat: g.cat, scale: g.scale || "yds", start: String(g.start), target: String(g.target), unit: g.unit, deadline: iso(g.deadline), testId: g.testId || "", note: g.note }
      : { mode: "new", title: "", cat: "Strength", scale: "yds", start: "0", target: "10", unit: "kg", deadline: iso(TODAY + 90), testId: "", note: "" } });
  }
  function gInfo(g, tests) {
    let cur = g.cur, hist = g.hist || [], t = null;
    if (g.testId) { t = tests.find(x => x.id === g.testId); if (t && t.hist.length) { hist = t.hist.filter(h => h.d >= g.startD); cur = t.hist[t.hist.length - 1].v; } }
    const span = g.target - g.start || 1; const pct = clamp((cur - g.start) / span, 0, 1);
    const el = clamp((TODAY - g.startD) / Math.max(1, g.deadline - g.startD), 0, 1); const r = pct / Math.max(el, 0.01);
    const status = pct >= 1 ? "Complete" : r >= 0.95 ? "On track" : r >= 0.8 ? "Slightly behind" : "Behind";
    const sc = pct >= 1 ? "#3E5A73" : r >= 0.95 ? "#3F6B4F" : r >= 0.8 ? "#B07A1E" : "#B5502A";
    const fv = v => g.cat === "Grade" ? ((g.scale === "v" ? VG : YDS)[Math.round(v)] || "—") : (g.unit === "kg" ? "+" + v + " kg" : v + (g.unit ? " " + g.unit : ""));
    const left = g.deadline - TODAY;
    const dl = pct >= 1 ? "Done" : left < 0 ? "Past deadline" : left === 0 ? "Due today" : left < 60 ? left + " days left" : Math.round(left / 7) + " weeks left";
    return { cur, hist, t, pct, el, status, sc, fv, dl };
  }
  const testLast = t => t.hist[t.hist.length - 1];
  const dueOf = t => { const l = testLast(t); return l ? l.d + t.freq * 7 : TODAY; };
  const latestBody = () => S.body.length ? S.body[S.body.length - 1] : null;
  const bodyweight = () => { const b = latestBody(); return b ? b.w : (currentAccount().weight || null); };
  const hangTest = () => S.tests.find(t => t.id === "t1") || S.tests.find(t => /max hang/i.test(t.name));

  const actions = {
    go,
    logNew: () => openNew(TODAY, "done"),
    editSession: arg => { const [id, force] = String(arg).split("|"); openEdit(id, force || undefined); },
    closeModal: () => set({ modal: null, armed: false }),
    weekToPlanner: i => { S.weekSel = +i; go("planner"); },
    goalToPage: id => { Object.assign(S, { selGoal: id, goalProg: "", newMs: "" }); go("goals"); },
    testToPage: id => { Object.assign(S, { selTest: id, testEdit: false }); go("tests"); },
    addSend: () => {
      const g = S.sendGrade; if (!g) return;
      const list = S.pyramid.map(x => x.slice()); const hit = list.find(x => x[0] === g);
      if (hit) hit[1]++; else list.push([g, 1]);
      set({ pyramid: sortPyramid(list) }); toast("Logged a " + g + " send");
    },

    // Check-in
    openCheck: () => {
      const c = S.checkins[TODAY] || { mot: 7, sleep: 7.5, finger: 7 };
      set({ modal: "check", form: { mot: String(c.mot), sleep: String(c.sleep), finger: String(c.finger) } });
    },
    saveCheck: () => {
      const f = S.form;
      set(s => ({ checkins: { ...s.checkins, [TODAY]: { mot: +f.mot, sleep: +f.sleep, finger: +f.finger, at: clockNow() } }, modal: null }));
      toast("Check-in saved");
    },

    // Session modal
    setStatus: k => setF("status", k),
    setWid: v => {
      const w = S.workouts.find(x => x.id === v);
      set(s => ({ form: { ...s.form, wid: v, ...(s.form.mode === "new" && w ? { dur: String(w.dur), rpe: String(w.rpe) } : {}) } }));
    },
    saveSession: () => {
      const f = S.form;
      const w = S.workouts.find(v => v.id === f.wid) || { name: "Session", type: "Sport" };
      const dur = Math.max(0, +f.dur || 0), rpe = clamp(+f.rpe || 1, 1, 10), day = clamp(+f.day, 0, DAYS - 1);
      set(s => ({ modal: null, sessions: f.mode === "new"
        ? [...s.sessions, { id: "s" + Date.now(), day, wid: f.wid, name: w.name, type: w.type, pdur: dur, prpe: rpe, status: f.status, dur, rpe, loc: f.loc, notes: f.notes }]
        : s.sessions.map(x => x.id !== f.sid ? x : { ...x, day, wid: f.wid, name: f.wid !== x.wid ? w.name : x.name, type: f.wid !== x.wid ? w.type : x.type, status: f.status, dur, rpe, loc: f.loc, notes: f.notes }) }));
      toast(f.status === "done" ? "Session logged" : f.status === "skipped" ? "Marked as skipped" : "Session saved to " + ld(day));
    },
    delSession: () => { const id = S.form.sid; set(s => ({ sessions: s.sessions.filter(x => x.id !== id), modal: null })); toast("Session removed"); },

    // Planner
    selWeek: i => set({ weekSel: +i }),
    prevW: () => set({ weekSel: clamp(S.weekSel - 1, 0, NW - 1) }),
    nextW: () => set({ weekSel: clamp(S.weekSel + 1, 0, NW - 1) }),
    thisW: () => set({ weekSel: CW }),
    addOnDay: d => openNew(+d, +d < TODAY ? "done" : "planned"),
    planAdd: () => { const w = S.weekSel; openNew(clamp(Math.max(w * 7, TODAY), w * 7, w * 7 + 6), "planned"); },
    setPhase: v => set(s => ({ weekPhases: s.weekPhases.map((p, i) => i === s.weekSel ? v : p) })),
    applyTpl: () => {
      const w = S.weekSel, ph = S.weekPhases[w];
      set(s => {
        const keep = s.sessions.filter(x => !(Math.floor(x.day / 7) === w && x.status === "planned" && x.day >= TODAY));
        const add = TPL[ph].filter(([dw]) => w * 7 + dw >= TODAY).map(([dw, wid], i) => {
          const wk = s.workouts.find(x => x.id === wid);
          return wk ? { id: "s" + Date.now() + "_" + i, day: w * 7 + dw, wid, name: wk.name, type: wk.type, pdur: wk.dur, prpe: wk.rpe, status: "planned", dur: wk.dur, rpe: wk.rpe, loc: "", notes: "" } : null;
        }).filter(Boolean);
        return { sessions: [...keep, ...add] };
      });
      toast(ph + " template applied to week " + (w + 1));
    },

    // Workouts
    selW: id => { const w = S.workouts.find(x => x.id === id); if (w) { reveal(".editor"); set({ selWorkout: id, draft: clone(w) }); } },
    wType: t => set({ wType: t }),
    newW: () => {
      const w = { id: "w" + Date.now(), name: "Untitled workout", type: "Strength", dur: 45, rpe: 6, desc: "", blocks: [B("Warm-up", "1", "1", "10 min", "—", "Easy")] };
      set(s => ({ workouts: [w, ...s.workouts], selWorkout: w.id, draft: clone(w), wType: "All", wSearch: "" }));
    },
    addB: () => set(s => ({ draft: { ...s.draft, blocks: [...s.draft.blocks, B("New block", "3", "5", "—", "2 min", "—")] } })),
    delB: i => set(s => ({ draft: { ...s.draft, blocks: s.draft.blocks.filter((_, j) => j !== +i) } })),
    saveW: () => {
      const d = { ...S.draft, dur: +S.draft.dur || 0, rpe: clamp(+S.draft.rpe || 1, 1, 10) };
      if (!String(d.name).trim()) return toast("Give the workout a name");
      set(s => ({ workouts: s.workouts.map(w => w.id === d.id ? d : w), draft: clone(d), sessions: s.sessions.map(x => x.wid === d.id ? { ...x, name: d.name, type: d.type } : x) }));
      toast("Workout saved");
    },
    dupW: () => {
      const d = S.draft; const w = { ...clone(d), dur: +d.dur || 0, rpe: +d.rpe || 5, id: "w" + Date.now(), name: d.name + " (copy)" };
      set(s => ({ workouts: [w, ...s.workouts], selWorkout: w.id, draft: clone(w) })); toast("Workout duplicated");
    },
    delW: () => {
      const id = S.selWorkout;
      set(s => { const ws = s.workouts.filter(w => w.id !== id); return { workouts: ws, selWorkout: ws[0] ? ws[0].id : null, draft: ws[0] ? clone(ws[0]) : null }; });
      toast("Workout deleted");
    },
    schedW: () => {
      const d = S.draft, day = +S.schedDay;
      set(s => ({ sessions: [...s.sessions, { id: "s" + Date.now(), day, wid: d.id, name: d.name, type: d.type, pdur: +d.dur || 0, prpe: +d.rpe || 5, status: "planned", dur: +d.dur || 0, rpe: +d.rpe || 5, loc: "", notes: "" }] }));
      toast(d.name + " added to " + ld(day));
    },

    // Tests
    selTest: id => { reveal(".test-detail"); set({ selTest: id, testEdit: false }); },
    newT: () => {
      const t = { id: "t" + Date.now(), name: "New test", cat: "Finger strength", unit: "kg", better: "higher", freq: 4, equip: "", steps: [], hist: [] };
      set(s => ({ tests: [...s.tests, t], selTest: t.id, testEdit: true, tDraft: { ...t, steps: "", freq: "4" } }));
    },
    editT: () => { const t = S.tests.find(x => x.id === S.selTest); if (t) set({ testEdit: true, tDraft: { ...clone(t), steps: t.steps.join("\n"), freq: String(t.freq) } }); },
    saveT: () => {
      const d = S.tDraft; if (!String(d.name).trim()) return toast("Give the protocol a name");
      set(s => ({ tests: s.tests.map(t => t.id !== d.id ? t : { ...t, ...d, hist: t.hist, freq: Math.max(1, +d.freq || 4), steps: String(d.steps).split("\n").map(x => x.trim()).filter(Boolean) }), testEdit: false }));
      toast("Protocol saved");
    },
    cancelT: () => set({ testEdit: false }),
    delT: () => {
      const id = S.selTest;
      set(s => { const ts = s.tests.filter(t => t.id !== id); return { tests: ts, selTest: ts[0] ? ts[0].id : null, testEdit: false, goals: s.goals.map(g => g.testId === id ? { ...g, testId: "" } : g) }; });
      toast("Protocol deleted");
    },
    logT: () => {
      const v = parseFloat(S.logVal); if (isNaN(v)) return toast("Enter a result first");
      const d = fromIso(S.logDate), id = S.selTest;
      set(s => ({ tests: s.tests.map(t => t.id !== id ? t : { ...t, hist: [...t.hist, { d, v, note: s.logNote }].sort((a, b) => a.d - b.d) }), logVal: "", logNote: "" }));
      toast("Result logged");
    },
    delR: i => { const id = S.selTest; set(s => ({ tests: s.tests.map(t => t.id !== id ? t : { ...t, hist: t.hist.filter((_, j) => j !== +i) }) })); toast("Result removed"); },
    planTest: () => {
      const t = S.tests.find(x => x.id === S.selTest); if (!t) return;
      const day = clamp(Math.max(dueOf(t), TODAY + 1), 0, DAYS - 1);
      set(s => ({ sessions: [...s.sessions, { id: "s" + Date.now(), day, wid: "", name: "Test: " + t.name, type: "Fingers", pdur: 30, prpe: 8, status: "planned", dur: 30, rpe: 8, loc: "", notes: "" }] }));
      toast("Test scheduled for " + ld(day));
    },

    // Goals
    selGoal: id => { reveal(".goal-detail"); set({ selGoal: id, goalProg: "", newMs: "" }); },
    newGoal: () => openGoal(null),
    editGoal: () => openGoal(S.goals.find(g => g.id === S.selGoal)),
    goalCat: c => set(s => ({ form: { ...s.form, cat: c,
      ...(c === "Grade" && s.form.cat !== "Grade" ? { start: "9", target: "12" } : {}),
      ...(c !== "Grade" && s.form.cat === "Grade" ? { start: "0", target: "10" } : {}) } })),
    saveGoal: () => {
      const f = S.form; if (!String(f.title).trim()) return toast("Give the goal a name");
      const start = +f.start || 0, target = +f.target || 0, deadline = fromIso(f.deadline), testId = f.cat === "Grade" ? "" : f.testId;
      set(s => {
        if (f.mode === "new") {
          const id = "g" + Date.now();
          return { goals: [...s.goals, { id, title: f.title.trim(), cat: f.cat, scale: f.cat === "Grade" ? f.scale : "", start, target, cur: start, unit: f.cat === "Grade" ? "" : f.unit, startD: TODAY, deadline, testId, note: f.note, hist: [{ d: TODAY, v: start }], ms: [] }], selGoal: id, modal: null };
        }
        return { goals: s.goals.map(g => g.id !== f.id ? g : { ...g, title: f.title.trim(), cat: f.cat, scale: f.cat === "Grade" ? f.scale : "", start, target, unit: f.cat === "Grade" ? "" : f.unit, deadline, testId, note: f.note }), modal: null };
      });
      toast("Goal saved");
    },
    updGoal: () => {
      const g = S.goals.find(x => x.id === S.selGoal); if (!g) return;
      const raw = S.goalProg; const v = g.cat === "Grade" ? (raw === "" ? g.cur : +raw) : parseFloat(raw);
      if (isNaN(v)) return toast("Enter a value");
      set(s => ({ goals: s.goals.map(x => x.id !== g.id ? x : { ...x, cur: v, hist: [...(x.hist || []).filter(h => h.d !== TODAY), { d: TODAY, v }].sort((a, b) => a.d - b.d) }), goalProg: "" }));
      toast("Progress updated");
    },
    togMs: i => set(s => ({ goals: s.goals.map(g => g.id !== s.selGoal ? g : { ...g, ms: g.ms.map((m, j) => j === +i ? { ...m, done: !m.done } : m) }) })),
    addMs: () => { const t = S.newMs.trim(); if (!t) return; set(s => ({ goals: s.goals.map(g => g.id !== s.selGoal ? g : { ...g, ms: [...g.ms, { t, done: false }] }), newMs: "" })); },
    delGoal: () => { set(s => { const gs = s.goals.filter(g => g.id !== s.selGoal); return { goals: gs, selGoal: gs[0] ? gs[0].id : null }; }); toast("Goal deleted"); },

    // Metrics
    metRange: n => set({ metRange: +n }),
    loadMode: k => set({ loadMode: k }),
    addBody: () => {
      const w = parseFloat(S.bodyW), bf = parseFloat(S.bodyBf);
      if (isNaN(w) || isNaN(bf)) return toast("Enter weight and body fat");
      set(s => ({ body: [...s.body.filter(x => x.d !== TODAY), { d: TODAY, w, bf }].sort((a, b) => a.d - b.d), bodyW: "", bodyBf: "" }));
      toast("Measurement added");
    },

    // Accounts
    openAccounts: () => set({ modal: "accounts", armed: false }),
    switchAccount: id => {
      const a = accounts.list.find(x => x.id === id); if (!a) return;
      if (id === accounts.currentId) return set({ modal: null });
      persistNow();
      accounts.currentId = id; saveAccounts();
      const page = S.page;
      S = { ...loadData(id) }; Object.assign(S, uiFor(S, page));
      ensureCurrentFormat();
      render(); window.scrollTo(0, 0);
      toast("Switched to " + a.name);
    },
    newAccount: () => set({ modal: "account", armed: false, form: { mode: "new", name: "", role: "Self-coached", home: "", weight: "", start: "blank" } }),
    editAccount: () => { const a = currentAccount(); set({ modal: "account", armed: false, form: { mode: "edit", id: a.id, name: a.name, role: a.role || "", home: a.home || "", weight: a.weight == null ? "" : String(a.weight), start: "" } }); },
    acctStart: k => setF("start", k),
    saveAccount: () => {
      const f = S.form, name = String(f.name || "").trim();
      if (!name) return toast("Add a name for this person");
      const wRaw = String(f.weight || "").trim(); const weight = wRaw === "" ? null : parseFloat(wRaw);
      if (weight != null && (isNaN(weight) || weight < 25 || weight > 250)) return toast("Enter a bodyweight between 25 and 250 kg");
      const details = { name, role: String(f.role || "").trim(), home: String(f.home || "").trim(), weight };
      if (f.mode === "edit") {
        const a = accounts.list.find(x => x.id === f.id); if (a) Object.assign(a, details);
        saveAccounts(); set({ modal: null }); toast("Profile saved"); return;
      }
      const used = new Set(accounts.list.map(a => a.color));
      const a = { id: "a" + Date.now().toString(36), ...details, color: AVATARS.find(c => !used.has(c)) || AVATARS[accounts.list.length % AVATARS.length] };
      if (!saveData(a.id, f.start === "sample" ? seedState() : blankState()) && storage) return toast("Could not save the new account in this browser");
      accounts.list.push(a); saveAccounts();
      actions.switchAccount(a.id);
      toast("Welcome, " + firstName(name) + ". This account is ready");
    },
    deleteAccount: () => {
      if (!S.armed) return set({ armed: true });
      const id = S.form.id; const removed = accounts.list.find(a => a.id === id);
      if (!removed || accounts.list.length < 2) return;
      try { storage && storage.removeItem(dataKey(id)); } catch { /* ignore */ }
      accounts.list = accounts.list.filter(a => a.id !== id);
      if (accounts.currentId === id) {
        clearTimeout(saveTimer); saveTimer = 0;
        accounts.currentId = accounts.list[0].id;
        const page = S.page; S = { ...loadData(accounts.currentId) }; Object.assign(S, uiFor(S, page));
      }
      saveAccounts(); S.modal = null; S.armed = false; render();
      toast(removed.name + "'s account deleted");
    }
  };

  /* =========================================================
     Markup helpers
     ========================================================= */
  const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const on = (name, arg) => ` data-on="${name}"` + (arg !== undefined ? ` data-arg="${esc(arg)}"` : "");
  const tap = (name, arg) => ` role="button" tabindex="0"` + on(name, arg);
  const bind = path => ` data-bind="${path}"`;
  const opt = (v, l, cur) => `<option value="${esc(v)}"${String(v) === String(cur) ? " selected" : ""}>${esc(l)}</option>`;
  const meta = x => x.dur + " min · RPE " + x.rpe + (x.loc ? " · " + x.loc : "");
  const pct = n => n.toFixed(1) + "%";
  const seg = (items, cls = "") => `<div class="seg ${cls}" role="group">${items.map(([label, action, arg, active]) => `<button type="button" class="${active ? "on" : ""}" aria-pressed="${active}"${on(action, arg)}>${esc(label)}</button>`).join("")}</div>`;
  const statCard = (s) => `<div class="stat card${s.go ? " is-link" : ""}"${s.go ? tap("go", s.go) : ""}><div class="kicker">${esc(s.l)}</div><div class="stat-val"${s.c ? ` style="color:${s.c}"` : ""}>${esc(s.v)}</div>${s.sub != null ? `<div class="stat-sub">${esc(s.sub)}</div>` : ""}</div>`;
  const miniStats = (list, cls = "") => `<div class="mini-stats ${cls}">${list.map(x => `<div><div class="mini-val">${esc(x.v)}</div><div class="mini-lbl">${esc(x.l)}</div></div>`).join("")}</div>`;
  const empty = (text, action, label) => `<div class="empty"><p>${esc(text)}</p>${action ? `<button type="button" class="btn xs"${on(action)}>${esc(label)}</button>` : ""}</div>`;
  const pageHead = (kicker, title, right = "") => `<header class="page-head"><div><div class="kicker">${esc(kicker)}</div><h1 class="h1">${esc(title)}</h1></div>${right}</header>`;

  /* =========================================================
     Chrome: sidebar, mobile header and tab bar
     ========================================================= */
  const NAV = [["Training", [["dashboard", "Dashboard", "Today"], ["planner", "Planner", "Plan"], ["workouts", "Workouts", "Train"]]], ["Performance", [["metrics", "Metrics", "Metrics"], ["goals", "Goals", "Goals"], ["tests", "Tests", "Tests"]]]];
  function vChrome() {
    const a = currentAccount(), bw = bodyweight(), ph = S.weekPhases;
    const sub = [a.role, bw ? bw + " kg" : ""].filter(Boolean).join(" · ") || "Climber";
    const avatar = (cls = "") => `<span class="avatar ${cls}" style="background:${esc(a.color || AVATARS[0])}" aria-hidden="true">${esc(initials(a.name))}</span>`;
    const brand = `<span class="brand-mark" aria-hidden="true"></span><span>Pocket</span>`;
    const side = `<aside class="side" aria-label="Main navigation">
      <button type="button" class="brand"${on("go", "dashboard")} aria-label="Pocket Training, dashboard">${brand}</button>
      ${NAV.map(([label, items]) => `<nav class="nav-sec" aria-label="${label}"><div class="nav-label">${label}</div>${items.map(([k, l]) => `<button type="button" class="nav-item"${S.page === k ? ' aria-current="page"' : ""}${on("go", k)}><span class="dot" aria-hidden="true"></span>${l}</button>`).join("")}</nav>`).join("")}
      <div class="side-foot">
        <button type="button" class="cycle-card"${on("go", "planner")} aria-label="Open planner, week ${CW + 1} of 12">
          <span class="nav-label flush">${CYCLE_NAME}</span>
          <span class="cycle-strip">${ph.map((p, i) => `<i style="background:${PH[p].c};opacity:${i <= CW ? 1 : 0.3}"></i>`).join("")}</span>
          <span class="cycle-label">Week ${CW + 1} of 12 · ${esc(ph[CW])}</span>
        </button>
        <button type="button" class="profile"${on("openAccounts")} aria-label="Switch or manage accounts" title="Switch or manage accounts">${avatar()}<span class="profile-copy"><span class="profile-name">${esc(a.name)}</span><span class="profile-sub">${esc(sub)}</span></span></button>
      </div>
    </aside>`;
    const top = `<header class="mtop"><button type="button" class="brand"${on("go", "dashboard")} aria-label="Pocket Training, dashboard">${brand}</button><span class="mtop-week">Wk ${CW + 1}/12 · ${esc(ph[CW])}</span><button type="button" class="avatar-btn"${on("openAccounts")} aria-label="Switch or manage accounts">${avatar()}</button></header>`;
    const tabs = `<nav class="mnav" aria-label="Sections">${NAV.flatMap(x => x[1]).map(([k, , short]) => `<button type="button"${S.page === k ? ' aria-current="page"' : ""}${on("go", k)}><span class="dot" aria-hidden="true"></span>${short}</button>`).join("")}</nav>`;
    return { side, top, tabs };
  }

  /* =========================================================
     Dashboard
     ========================================================= */
  function vDashboard() {
    const s = S, ses = s.sessions, ph = s.weekPhases, cw = CW, a = currentAccount();
    const ws = [...Array(NW)].map((_, w) => weekStats(ses, w)); const maxW = Math.max(...ws.map(x => Math.max(x.p, x.d)), 1);
    const td = ses.filter(x => x.day === TODAY);
    const types = [...new Set(td.map(x => x.type))];
    const ck = s.checkins[TODAY];
    const hour = new Date().getHours();
    const hello = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";

    const head = pageHead(fullDate(TODAY) + " · " + CYCLE_NAME, hello + ", " + firstName(a.name),
      `<div class="head-actions"><button type="button" class="btn"${on("go", "tests")}>Log a test</button><button type="button" class="btn primary"${on("logNew")}>Log session</button></div>`);

    const hero = `<section class="hero" aria-label="Today's session">
      <div class="row-between"><span class="hero-kicker">Today's session</span><span class="chip-rust">${esc(ph[cw])} phase · Wk ${cw + 1}</span></div>
      <h2 class="hero-title">${esc(types.length ? types.map((t, i) => i ? t.toLowerCase() : t).join(" + ") : "Rest day")}</h2>
      <div class="stack-8">${td.map(x => {
        const done = x.status === "done";
        return `<div class="today-item"><span class="dot9" style="background:${TC[x.type] || "#8A7A6B"}"></span><div class="grow"><div class="today-name">${esc(x.name)}</div><div class="today-meta">${esc(meta(x))}</div></div><button type="button" class="hero-btn${done ? " is-done" : ""}"${on("editSession", x.id + "|done")}>${done ? "Done ✓" : x.status === "skipped" ? "Skipped" : "Mark done"}</button></div>`;
      }).join("")}${td.length ? "" : `<div class="today-item rest">Nothing scheduled. Recover, or add a session from the planner.</div>`}</div>
      <div class="hero-foot"><div class="row-between hero-sub"><span>Cycle progress</span><button type="button" class="hero-link"${on("go", "planner")}>Week ${cw + 1} of 12 · open planner</button></div>
        <div class="cycle-bars" aria-hidden="true">${ph.map((p, i) => `<i style="height:${i === cw ? 12 : 7}px;background:${PH[p].c};opacity:${i <= cw ? 1 : 0.3}"></i>`).join("")}</div></div>
    </section>`;

    const motPts = [...Array(14)].map((_, i) => ({ i, c: s.checkins[TODAY - 13 + i] })).filter(x => x.c);
    const spark = motPts.map(({ i, c }) => (6 + i * (288 / 13)).toFixed(1) + "," + (56 - (c.mot - 2) / 8 * 50).toFixed(1)).join(" ");
    const first = td.find(x => x.status !== "skipped");
    let msg, tone;
    if (!ck) { msg = "Check in to get a call on today's training."; tone = "neutral"; }
    else {
      const good = ck.finger >= 7 && ck.sleep >= 7 && ck.mot >= 6, bad = ck.finger <= 5 || ck.sleep < 6;
      const fingersDay = td.some(x => x.type === "Fingers");
      msg = good ? "Fresh fingers, good sleep. Green light for " + (fingersDay ? "max hangs" : first ? first.name.toLowerCase() : "a hard session") + "."
        : bad ? (fingersDay ? "Fingers or sleep are down. Swap max hangs for repeaters at 80% and cut a set." : "Fingers or sleep are down. Drop the intensity today and cut a set.")
        : "Moderate readiness. Keep intensity, trim volume by a set.";
      tone = good ? "good" : bad ? "bad" : "mid";
    }
    const ready = `<section class="card lg ready" aria-label="Readiness">
      <div class="row-between"><span class="kicker">Readiness</span><button type="button" class="link green"${on("openCheck")}>${ck ? "Checked in " + esc(ck.at || "today") + " · Edit" : "Check in"}</button></div>
      <div class="ready-grid">${[["Motivation", ck && ck.mot, "/10"], ["Sleep", ck && ck.sleep, "h"], ["Finger feel", ck && ck.finger, "/10"]].map(([l, v, u]) => `<div><div class="ready-val">${v != null ? esc(v) + `<span class="ready-unit"> ${u}</span>` : "—"}</div><div class="ready-lbl">${l}</div></div>`).join("")}</div>
      <div><div class="small-muted">Motivation, last 14 days</div>${motPts.length > 1 ? `<svg class="spark" viewBox="0 0 300 60" preserveAspectRatio="none" role="img" aria-label="Motivation trend"><polyline points="${spark}"></polyline></svg>` : `<div class="spark-empty">Check in daily to build this trend.</div>`}</div>
      <div class="note-box ${tone}">${esc(msg)}</div>
    </section>`;

    const due = ses.filter(x => x.day < TODAY || (x.day === TODAY && x.status !== "planned")); const dn = due.filter(x => x.status === "done").length;
    const t1 = hangTest(); const t1l = t1 && testLast(t1);
    const g3 = s.goals.find(g => g.id === "g3") || s.goals.find(g => /outdoor/i.test(g.title)); const g3i = g3 && gInfo(g3, s.tests);
    const bw = bodyweight();
    const stats = [
      { l: "This week", v: fmtN(ws[cw].d), sub: "of " + fmtN(ws[cw].p) + " AU planned", go: "metrics" },
      { l: "Adherence", v: due.length ? Math.round(dn / due.length * 100) + "%" : "—", sub: due.length ? dn + " of " + due.length + " sessions" : "No sessions due yet", go: "planner" },
      { l: "Max hang 20mm", v: t1l ? "+" + t1l.v + " kg" : "—", sub: t1l && bw ? Math.round((bw + t1l.v) / bw * 100) + "% bodyweight" : "Log a max hang test", go: "tests" },
      { l: "Outdoor days", v: g3i ? String(g3i.cur) : "—", sub: g3 ? "of " + g3.target + " for 2026" : "Set an outdoor-days goal", go: "goals" }
    ];

    const bars = `<section class="card"><div class="row-between baseline"><h2 class="card-title">Training load</h2><div class="legend"><span><i class="sw" style="background:#B5502A"></i>Completed</span><span><i class="sw dashed"></i>Planned</span></div></div>
      <div class="bars h170">${ws.map((x, i) => `<div class="bar is-link" title="Week ${i + 1}: ${fmtN(x.d)} / ${fmtN(x.p)} AU"${tap("weekToPlanner", i)} aria-label="Week ${i + 1}: ${fmtN(x.d)} of ${fmtN(x.p)} AU"><div class="bar-track"><div class="bar-plan" style="height:${pct(x.p / maxW * 100)}"></div><div class="bar-done" style="height:${pct(x.d / maxW * 100)};background:${PH[ph[i]].c}"></div></div><div class="bar-label"${i === cw ? ' style="color:#B5502A"' : ""}>W${i + 1}</div></div>`).join("")}</div></section>`;

    const upcoming = ses.filter(x => x.day > TODAY && x.status === "planned").sort((a, b) => a.day - b.day).slice(0, 5);
    const next = `<section class="card"><div class="row-between baseline mb10"><h2 class="card-title">Up next</h2><button type="button" class="link"${on("go", "planner")}>Planner →</button></div>
      ${upcoming.length ? upcoming.map(x => `<div class="row-line is-link"${tap("editSession", x.id)}><div class="row-day">${(DOW[dow(x.day)] + " " + dt(x.day).getDate()).toUpperCase()}</div><span class="dot8" style="background:${TC[x.type] || "#8A7A6B"}"></span><div class="grow"><div class="row-name">${esc(x.name)}</div><div class="row-meta">${esc(meta(x))}</div></div></div>`).join("") : empty("No planned sessions ahead.", "go", "Open planner").replace('data-on="go"', 'data-on="go" data-arg="planner"')}
    </section>`;

    const goalsI = s.goals.map(g => ({ g, i: gInfo(g, s.tests) })).filter(x => x.i.pct < 1).slice(0, 3);
    const goalsCard = `<section class="card stack-14"><div class="row-between baseline"><h2 class="card-title">Goals</h2><button type="button" class="link"${on("go", "goals")}>All goals →</button></div>
      ${goalsI.length ? goalsI.map(({ g, i }) => `<div class="mini-goal is-link"${tap("goalToPage", g.id)}><div class="row-between gap8 fs135"><span class="fw6">${esc(g.title)}</span><span class="nowrap fs12 fw6" style="color:${i.sc}">${i.status}</span></div><div class="track"><div class="fill" style="width:${(i.pct * 100).toFixed(0)}%;background:${i.sc}"></div></div><div class="fs12 muted">${esc(i.fv(i.cur))} now · due ${sd(g.deadline)}</div></div>`).join("") : empty("No active goals yet.", "newGoal", "Set a goal")}
    </section>`;

    const all = []; s.tests.forEach(t => t.hist.forEach((h, j) => all.push({ t, h, prev: t.hist[j - 1] })));
    const recent = all.sort((a, b) => b.h.d - a.h.d).slice(0, 3);
    const testsCard = `<section class="card"><div class="row-between baseline mb6"><h2 class="card-title">Recent tests</h2><button type="button" class="link"${on("go", "tests")}>Tests →</button></div>
      ${recent.length ? recent.map(({ t, h, prev }) => { const dl = prev ? +(h.v - prev.v).toFixed(1) : 0; return `<div class="row-line pad10 is-link"${tap("testToPage", t.id)}><div class="grow"><div class="row-name">${esc(t.name)}</div><div class="row-meta">${sd(h.d)}</div></div><div class="right"><div class="test-val">${(t.unit === "kg" ? "+" : "") + esc(h.v + " " + t.unit)}</div><div class="fs12 fw6" style="color:${dl >= 0 ? "#3F6B4F" : "#B5502A"}">${prev ? (dl >= 0 ? "▲ " : "▼ ") + Math.abs(dl) + " " + esc(t.unit) : "First result"}</div></div></div>`; }).join("") : empty("No results yet. Log a test to track progress.", "go", "Open tests").replace('data-on="go"', 'data-on="go" data-arg="tests"')}
    </section>`;

    const pyr = sortPyramid(s.pyramid);
    const yds = pyr.filter(x => !gradeIndex(x[0]).v).slice(0, 5), vs = pyr.filter(x => gradeIndex(x[0]).v).slice(0, 2);
    const rows = [...yds, ...vs]; const peak = Math.max(1, ...rows.map(x => x[1]));
    const pyramid = `<section class="card"><h2 class="card-title mb12">Send pyramid · 2026</h2>
      ${rows.length ? `<div class="pyramid">${rows.map(([g, n]) => { const isV = gradeIndex(g).v; return `<div class="pyr-row"><span>${esc(g)}</span><div class="pyr-mid"><div style="width:${(n / peak * 100).toFixed(0)}%;background:${isV ? "#8E3B2A" : "#B5502A"}"></div></div><span class="muted">${n}</span></div>`; }).join("")}</div>` : `<p class="empty-line">Log sends to build your pyramid.</p>`}
      <div class="inline-add mt14"><select class="field sm" aria-label="Grade"${bind("sendGrade")}><optgroup label="Routes">${YDS.map(g => opt(g, g, s.sendGrade)).join("")}</optgroup><optgroup label="Boulders">${VG.map(g => opt(g, g, s.sendGrade)).join("")}</optgroup></select><button type="button" class="btn xs"${on("addSend")}>Log send</button></div>
    </section>`;

    return `${head}<div class="g-hero">${hero}${ready}</div><div class="g-4">${stats.map(statCard).join("")}</div><div class="g-hero">${bars}${next}</div><div class="g-3">${goalsCard}${testsCard}${pyramid}</div>`;
  }

  /* =========================================================
     Planner
     ========================================================= */
  function vPlanner() {
    const s = S, ses = s.sessions, ph = s.weekPhases, w = s.weekSel, cw = CW;
    const ws = [...Array(NW)].map((_, i) => weekStats(ses, i)); const maxW = Math.max(...ws.map(x => Math.max(x.p, x.d)), 1);
    const groups = []; ph.forEach(p => { const last = groups[groups.length - 1]; if (last && last.name === p) last.span++; else groups.push({ name: p, span: 1, color: PH[p].c }); });
    const head = pageHead(CYCLE_NAME + " · " + sd(0) + " – " + sd(DAYS - 1) + " · 12 weeks", "Planner", `<button type="button" class="btn primary"${on("planAdd")}>Add session</button>`);
    const strip = `<section class="card strip-card"><div class="scroll-x"><div class="strip-inner">
      <div class="g-12">${groups.map(g => `<div class="phase-group" style="grid-column:span ${g.span}"><div class="phase-name" style="color:${g.color}">${esc(g.name)}</div><div class="phase-line" style="background:${g.color}"></div></div>`).join("")}</div>
      <div class="g-12">${ws.map((x, i) => `<div class="week-cell${i === w ? " sel" : i === cw ? " cur" : ""}"${tap("selWeek", i)} aria-pressed="${i === w}" aria-label="Week ${i + 1}, ${x.nd} of ${x.n} sessions done"><div class="row-between baseline"><span class="week-lbl">W${i + 1}</span><span class="mono10 nowrap wk-date">${sd(i * 7)}</span></div><div class="week-mini"><div class="bar-plan r4" style="height:${pct(x.p / maxW * 100)}"></div><div class="bar-done r4" style="height:${pct(x.d / maxW * 100)};background:${PH[ph[i]].c}"></div></div><div class="mono10">${x.nd}/${x.n} done</div></div>`).join("")}</div>
    </div></div></section>`;

    const days = [...Array(7)].map((_, k) => {
      const d = w * 7 + k; const it = ses.filter(x => x.day === d); const isT = d === TODAY;
      return `<div class="day${isT ? " today" : ""}"><div class="day-head"><span class="day-dow">${DOW[k]}${isT ? " · Today" : ""}</span><span class="mono11">${sd(d)}</span></div>
        ${it.map(x => {
          const stt = x.status === "done" ? ["Done", "done"] : x.status === "skipped" ? ["Skipped", "skip"] : d < TODAY ? ["Not logged", "late"] : ["Planned", "plan"];
          return `<div class="sess${x.status === "skipped" ? " dim" : ""}" style="box-shadow:inset 3px 0 0 ${TC[x.type] || "#8A7A6B"}"${tap("editSession", x.id)}><div class="sess-name">${esc(x.name)}</div><div class="sess-meta">${esc(meta(x))}</div><span class="pill ${stt[1]}">${stt[0]}</span></div>`;
        }).join("")}
        <button type="button" class="add-day"${on("addOnDay", d)} aria-label="Add session on ${ld(d)}">+ Add</button></div>`;
    }).join("");

    const mins = {}; ses.filter(x => Math.floor(x.day / 7) === w && x.status !== "skipped").forEach(x => { mins[x.type] = (mins[x.type] || 0) + x.dur; });
    const mx = Math.max(1, ...Object.values(mins));
    const side = `<aside class="card stack-16 plan-side" aria-label="Week settings">
      <label class="kicker" for="phase-select">Week phase</label>
      <select id="phase-select" class="field phase-select" style="color:${PH[ph[w]].c}" data-oninput="setPhase">${PHN.map(p => opt(p, p, ph[w])).join("")}</select>
      <p class="focus-text">${esc(PH[ph[w]].f)}</p>
      <button type="button" class="btn white xs"${on("applyTpl")}>Fill remaining days from phase template</button>
      <div class="divider stack-10">${[["Planned load", fmtN(ws[w].p) + " AU"], ["Completed", fmtN(ws[w].d) + " AU"], ["Sessions done", ws[w].nd + " / " + ws[w].n]].map(([l, v]) => `<div class="row-between baseline"><span class="fs13 muted">${l}</span><span class="sum-val">${v}</span></div>`).join("")}</div>
      <div class="divider stack-8"><div class="kicker">Minutes by type</div>${Object.keys(mins).length ? Object.entries(mins).sort((a, b) => b[1] - a[1]).map(([t, m]) => `<div class="mix-row"><span>${t}</span><div class="track h8"><div class="fill" style="width:${(m / mx * 100).toFixed(0)}%;background:${TC[t] || "#8A7A6B"}"></div></div><span class="mono11 right muted">${m}</span></div>`).join("") : `<p class="empty-line">Nothing planned this week.</p>`}</div>
    </aside>`;

    return `${head}${strip}<div class="plan-layout"><div class="stack-12 min0">
      <div class="week-nav"><button type="button" class="sq-btn"${on("prevW")} aria-label="Previous week"${w === 0 ? " disabled" : ""}>‹</button><button type="button" class="sq-btn"${on("nextW")} aria-label="Next week"${w === NW - 1 ? " disabled" : ""}>›</button><h2 class="week-title">Week ${w + 1} · ${sd(w * 7)} – ${sd(w * 7 + 6)}</h2><button type="button" class="btn xs push"${on("thisW")}>This week</button></div>
      <div class="days">${days}</div></div>${side}</div>`;
  }

  /* =========================================================
     Workouts
     ========================================================= */
  function vWorkouts() {
    const s = S, ses = s.sessions;
    const q = s.wSearch.toLowerCase();
    const list = s.workouts.filter(w => (s.wType === "All" || w.type === s.wType) && (!q || w.name.toLowerCase().includes(q)));
    const head = pageHead(s.workouts.length + " protocols", "Workouts", `<button type="button" class="btn primary"${on("newW")}>New workout</button>`);
    const left = `<div class="stack-10">
      <input class="field search" type="search" placeholder="Search workouts" aria-label="Search workouts" value="${esc(s.wSearch)}"${bind("wSearch")}>
      <div class="chips">${["All", ...TYPES].map(t => `<button type="button" class="chip${s.wType === t ? " on" : ""}" aria-pressed="${s.wType === t}"${on("wType", t)}>${t}</button>`).join("")}</div>
      ${list.map(w => `<div class="list-card${w.id === s.selWorkout ? " sel" : ""}"${tap("selW", w.id)}><div class="list-bar" style="background:${TC[w.type] || "#8A7A6B"}"></div><div class="grow"><div class="list-name">${esc(w.name)}</div><div class="list-meta">${esc(w.type + " · " + w.dur + " min · RPE " + w.rpe + " · " + w.blocks.length + (w.blocks.length === 1 ? " block" : " blocks"))}</div></div><span class="mono105 nowrap">${ses.filter(x => x.wid === w.id).length}×</span></div>`).join("")}
      ${list.length ? "" : `<div class="dashed-empty">No workouts match.</div>`}
    </div>`;
    const d = s.draft;
    let right = `<div class="card">${empty("No workout selected. Create one to start your library.", "newW", "New workout")}</div>`;
    if (d) {
      const saved = s.workouts.find(w => w.id === d.id);
      const dirty = !saved || JSON.stringify({ ...saved, dur: String(saved.dur), rpe: String(saved.rpe) }) !== JSON.stringify({ ...d, dur: String(d.dur), rpe: String(d.rpe) });
      const COLS = ["Block", "Sets", "Reps", "Work", "Rest", "Load / grade"];
      right = `<section class="editor card flush" aria-label="Workout editor"><div class="editor-band" style="background:${TC[d.type] || "#8A7A6B"}"></div><div class="editor-body">
        <div class="row-between gap12"><input class="title-input" aria-label="Workout name" value="${esc(d.name)}"${bind("draft.name")}><span class="fs125 fw6 nowrap" style="color:${dirty ? "#B07A1E" : "#3F6B4F"}">${dirty ? "Unsaved changes" : "Saved"}</span></div>
        <div class="g-4i">
          <label class="lbl">Type<select class="field"${bind("draft.type")}>${TYPES.map(t => opt(t, t, d.type)).join("")}</select></label>
          <label class="lbl">Duration (min)<input class="field" type="number" min="0" inputmode="numeric" value="${esc(d.dur)}"${bind("draft.dur")}></label>
          <label class="lbl">Target RPE · ${esc(d.rpe)}<input type="range" min="1" max="10" value="${esc(d.rpe)}" class="mt10"${bind("draft.rpe")}></label>
          <div class="lbl">Est. load<div class="est">${fmtN((+d.dur || 0) * (+d.rpe || 0))} AU</div></div>
        </div>
        <label class="lbl">Notes &amp; intent<textarea class="field" rows="2"${bind("draft.desc")}>${esc(d.desc)}</textarea></label>
        <div class="scroll-x"><div class="blocks">
          <div class="blk-row blk-head"><span></span>${COLS.map(c => `<span>${c}</span>`).join("")}<span></span></div>
          ${d.blocks.map((b, i) => `<div class="blk-row"><span class="blk-n">${String(i + 1).padStart(2, "0")}</span>${["name", "sets", "reps", "work", "rest", "load"].map((k, j) => `<input class="blk-input${k === "name" ? " fw6" : ""}" aria-label="Block ${i + 1} ${COLS[j].toLowerCase()}" value="${esc(b[k])}"${bind("draft.blocks." + i + "." + k)}>`).join("")}<button type="button" class="icon-btn"${on("delB", i)} aria-label="Remove block ${i + 1}" title="Remove block">×</button></div>`).join("")}
          <button type="button" class="btn dashed xs self-start mt4"${on("addB")}>+ Add block</button>
        </div></div>
        <div class="editor-foot">
          <select class="field auto" aria-label="Day to schedule"${bind("schedDay")}>${[...Array(14)].map((_, i) => TODAY + i).filter(v => v < DAYS).map(v => opt(v, ld(v) + (v === TODAY ? " (today)" : ""), s.schedDay)).join("")}</select>
          <button type="button" class="btn sm fw6"${on("schedW")}>Add to plan</button>
          <div class="grow"></div>
          <button type="button" class="btn sm danger"${on("delW")}>Delete</button>
          <button type="button" class="btn sm"${on("dupW")}>Duplicate</button>
          <button type="button" class="btn sm primary"${on("saveW")}>Save workout</button>
        </div>
      </div></section>`;
    }
    return `${head}<div class="work-layout">${left}${right}</div>`;
  }

  /* =========================================================
     Metrics
     ========================================================= */
  const chart = (inner, from, to, h = 150, extraCls = "") => `<div class="chart ${extraCls}" style="height:${h}px">${inner}<div class="axis-l">${esc(from)}</div><div class="axis-r">${esc(to)}</div></div>`;
  const chartMsg = text => `<div class="chart-msg">${esc(text)}</div>`;
  function vMetrics() {
    const s = S, ses = s.sessions, ph = s.weekPhases, cw = CW;
    const load = dayLoads(ses); const ws = [...Array(NW)].map((_, w) => weekStats(ses, w)); const maxW = Math.max(...ws.map(x => Math.max(x.p, x.d)), 1);
    const R = s.metRange === 47 ? TODAY + 1 : s.metRange; const from = Math.max(0, TODAY - R + 1);
    const days = []; for (let d = from; d <= TODAY; d++) days.push(d);
    const sum = (a, b) => { let t = 0; for (let d = Math.max(0, a); d <= b; d++) t += load[d] || 0; return t; };
    const acute = sum(TODAY - 6, TODAY), chronic = sum(TODAY - 27, TODAY) / 4, acwr = chronic ? acute / chronic : 0;
    const inR = ses.filter(x => x.day >= from && x.day <= TODAY && x.status === "done");
    let streak = 0; for (let w = cw - 1; w >= 0; w--) { if (ws[w].n && ws[w].nd / ws[w].n >= 0.8) streak++; else break; }
    let best = 0, run = 0; for (let w = 0; w < cw; w++) { if (ws[w].n && ws[w].nd / ws[w].n >= 0.8) { run++; best = Math.max(best, run); } else run = 0; }

    const head = pageHead("Load · strength · body · wellness", "Metrics", seg([[ "14 d", "metRange", 14, s.metRange === 14], ["28 d", "metRange", 28, s.metRange === 28], ["Cycle", "metRange", 47, s.metRange === 47]]));
    const kpis = [
      { l: "Acute load · 7 d", v: fmtN(acute), sub: "AU (minutes × session RPE)", c: "#2A211B" },
      { l: "Acute : chronic", v: chronic ? acwr.toFixed(2) : "—", sub: !chronic ? "Needs a few weeks of logs" : acwr > 1.3 ? "Above 1.3: load spike" : acwr < 0.8 ? "Below 0.8: detraining" : "Inside the 0.8–1.3 range", c: !chronic ? "#2A211B" : acwr > 1.3 ? "#B5502A" : acwr < 0.8 ? "#B07A1E" : "#3F6B4F" },
      { l: "Sessions done", v: String(inR.length), sub: "last " + days.length + " days", c: "#2A211B" },
      { l: "Avg session RPE", v: inR.length ? (inR.reduce((a, x) => a + x.rpe, 0) / inR.length).toFixed(1) : "—", sub: "last " + days.length + " days", c: "#2A211B" }
    ];

    const byType = s.loadMode === "type";
    const mBars = ws.map((x, w) => {
      let segs;
      if (byType) { const tl = {}; ses.forEach(y => { if (Math.floor(y.day / 7) === w && y.status === "done") tl[y.type] = (tl[y.type] || 0) + y.dur * y.rpe; }); segs = TYPES.filter(t => tl[t]).map(t => ({ h: pct(tl[t] / Math.max(1, x.d) * 100), c: TC[t] })); }
      else segs = [{ h: "100%", c: PH[ph[w]].c }];
      return `<div class="bar" title="Week ${w + 1} · ${esc(ph[w])}: ${fmtN(x.d)} / ${fmtN(x.p)} AU"><div class="bar-track"><div class="bar-plan" style="height:${pct(x.p / maxW * 100)};opacity:${byType ? 0 : 1}"></div><div class="bar-stack" style="height:${pct(x.d / maxW * 100)}">${segs.map(g => `<div style="height:${g.h};background:${g.c}"></div>`).join("")}</div></div><div class="bar-label">W${w + 1}</div></div>`;
    }).join("");
    const legend = (byType ? TYPES.map(t => [t, TC[t]]) : PHN.map(p => [p, PH[p].c])).map(([l, c]) => `<span><i class="sw sm" style="background:${c}"></i>${l}</span>`).join("");
    const loadCard = `<section class="card"><div class="row-between center"><h2 class="card-title">Weekly training load</h2>${seg([["Total", "loadMode", "total", !byType], ["By type", "loadMode", "type", byType]], "sm")}</div><div class="bars h200">${mBars}</div><div class="legend wrap mt12">${legend}</div></section>`;

    const mxL = Math.max(1, ...load);
    const heat = load.map((l, d) => `<div title="${ld(d)}${d <= TODAY ? ": " + fmtN(l) + " AU" : ""}" style="background:${d > TODAY ? "transparent" : l ? "rgba(181,80,42," + (0.18 + 0.82 * Math.min(1, l / mxL * 1.3)).toFixed(2) + ")" : "#EDE5D8"};box-shadow:${d === TODAY ? "0 0 0 2px #231B16" : d > TODAY ? "inset 0 0 0 1px #E4DACB" : "none"}"></div>`).join("");
    const consistency = `<section class="card stack-14"><h2 class="card-title">Consistency</h2>
      <div class="heat-wrap"><div class="heat-days" aria-hidden="true"><span>M</span><span></span><span>W</span><span></span><span>F</span><span></span><span>S</span></div><div class="heat" role="img" aria-label="Daily training load heatmap for the cycle">${heat}</div></div>
      <div class="row-between fs12 muted"><span>${sd(0)}</span><span class="heat-key">Less <i style="background:rgba(181,80,42,.2)"></i><i style="background:rgba(181,80,42,.6)"></i><i style="background:#B5502A"></i> More</span><span>${sd(DAYS - 1)}</span></div>
      <div class="g-2 divider">${[[streak + " wk", "Current streak ≥ 80% adherence"], [best + " wk", "Longest streak this cycle"]].map(([v, l]) => `<div><div class="streak-val">${v}</div><div class="fs12 muted">${l}</div></div>`).join("")}</div>
    </section>`;

    const bw0 = s.body[0] ? s.body[0].w : (currentAccount().weight || 70);
    const bwAt = d => { let b = bw0; s.body.forEach(x => { if (x.d <= d) b = x.w; }); return b; };
    const t1 = hangTest(), t4 = s.tests.find(t => t.id === "t4") || s.tests.find(t => /repeater/i.test(t.name));
    const fing = ser(t1 ? t1.hist.map(h => { const p = (bwAt(h.d) + h.v) / bwAt(h.d) * 100; return { d: h.d, v: p, lab: sd(h.d) + ": +" + h.v + " kg", val: Math.round(p) + "%" }; }) : []);
    const t1l = t1 && testLast(t1), bwNow = latestBody(), bwVal = bodyweight();
    const fingCard = `<section class="card stack-12"><div class="row-between baseline gap8"><h2 class="card-title">Finger strength</h2><span class="fs12 muted">Max hang 20 mm, % bodyweight</span></div>
      ${fing.dots.length ? chart(`<svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><polyline class="ln" style="stroke:#C08A28;stroke-width:2.5" points="${fing.pts}"></polyline></svg>${fing.dots.map(p => `<div class="cdot ring" title="${esc(p.lab)}" style="left:${p.l};top:${p.t};border-color:#C08A28"></div>`).join("")}${fing.lbl.map(p => `<div class="clabel" style="left:${p.l};top:${p.t}">${esc(p.val)}</div>`).join("")}`, fing.from, fing.to) : chart(chartMsg("Log a max hang test to chart finger strength."), "", "")}
      ${miniStats([{ v: t1l ? "+" + t1l.v + " kg" : "—", l: "Max hang" }, { v: t1l && bwVal ? Math.round((bwVal + t1l.v) / bwVal * 100) + "%" : "—", l: "of bodyweight" }, { v: t4 && testLast(t4) ? testLast(t4).v + " reps" : "—", l: "Repeaters 7:3" }], "divider")}
    </section>`;

    const bwS = ser(s.body.map(x => ({ d: x.d, v: x.w, lab: sd(x.d) + ": " + x.w + " kg" })));
    const bfS = s.body.length ? ser(s.body.map(x => ({ d: x.d, v: x.bf })), { d0: s.body[0].d, d1: s.body[s.body.length - 1].d }) : { pts: "" };
    const b0 = s.body[0];
    const bodyCard = `<section class="card stack-12"><div class="row-between baseline gap8"><h2 class="card-title">Body composition</h2><div class="legend"><span><i class="sw line" style="background:#3F6B4F"></i>Weight</span><span><i class="sw line" style="background:#C08A28"></i>Body fat</span></div></div>
      ${s.body.length ? chart(`<svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><polyline class="ln" style="stroke:#3F6B4F;stroke-width:2.5" points="${bwS.pts}"></polyline><polyline class="ln" style="stroke:#C08A28;stroke-width:2;stroke-dasharray:4 3" points="${bfS.pts}"></polyline></svg>${bwS.dots.map(p => `<div class="cdot solid sm" title="${esc(p.lab)}" style="left:${p.l};top:${p.t};background:#3F6B4F"></div>`).join("")}`, bwS.from, bwS.to) : chart(chartMsg("Add a measurement below to start tracking."), "", "")}
      ${miniStats(bwNow ? [{ v: bwNow.w + " kg", l: "Weight · " + (bwNow.w - b0.w >= 0 ? "+" : "") + (bwNow.w - b0.w).toFixed(1) + " YTD" }, { v: bwNow.bf + "%", l: "Body fat · " + (bwNow.bf - b0.bf).toFixed(1) + " YTD" }, { v: (bwNow.w * (1 - bwNow.bf / 100)).toFixed(1) + " kg", l: "Lean mass" }] : [{ v: "—", l: "Weight" }, { v: "—", l: "Body fat" }, { v: "—", l: "Lean mass" }], "divider")}
      <div class="body-add"><input class="field sm" type="number" step="0.1" inputmode="decimal" placeholder="Weight kg" aria-label="Weight in kg" value="${esc(s.bodyW)}"${bind("bodyW")}><input class="field sm" type="number" step="0.1" inputmode="decimal" placeholder="Body fat %" aria-label="Body fat percent" value="${esc(s.bodyBf)}"${bind("bodyBf")}><button type="button" class="btn xs green"${on("addBody")}>Add</button></div>
    </section>`;

    const ckDays = days.filter(d => s.checkins[d]);
    const ln = (k, lo, hi) => ser(ckDays.map(d => ({ d, v: s.checkins[d][k] })), { d0: from, d1: TODAY, lo, hi }).pts;
    const avg = k => ckDays.length ? (ckDays.reduce((a, d) => a + s.checkins[d][k], 0) / ckDays.length).toFixed(1) : "—";
    const wellCard = `<section class="card stack-12"><div class="row-between baseline gap8"><h2 class="card-title">Wellness</h2><div class="legend">${[["Motivation", "#B5502A"], ["Sleep", "#3E5A73"], ["Fingers", "#3F6B4F"]].map(([l, c]) => `<span><i class="sw line" style="background:${c}"></i>${l}</span>`).join("")}</div></div>
      ${ckDays.length > 1 ? chart(`<svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><polyline class="ln" style="stroke:#B5502A;stroke-width:2" points="${ln("mot", 0, 10)}"></polyline><polyline class="ln" style="stroke:#3E5A73;stroke-width:2" points="${ln("sleep", 4, 10)}"></polyline><polyline class="ln" style="stroke:#3F6B4F;stroke-width:2;stroke-dasharray:3 3" points="${ln("finger", 0, 10)}"></polyline></svg>`, sd(from), "Today") : chart(chartMsg("Daily check-ins will show up here."), "", "")}
      ${miniStats([{ v: avg("mot"), l: "Motivation" }, { v: ckDays.length ? avg("sleep") + " h" : "—", l: "Sleep" }, { v: avg("finger"), l: "Finger feel" }, { v: String(ckDays.length), l: "Check-ins" }], "four divider")}
    </section>`;

    const CO = [["sleep", "Sleep (h)"], ["mot", "Motivation"], ["finger", "Finger feel"], ["load", "Load, same day"], ["prev", "Load, previous day"]];
    const needsCk = k => k !== "load" && k !== "prev";
    const cDays = days.filter(d => (!needsCk(s.corrX) || s.checkins[d]) && (!needsCk(s.corrY) || s.checkins[d]));
    const get = (d, k) => k === "load" ? load[d] || 0 : k === "prev" ? load[d - 1] || 0 : s.checkins[d][k];
    const xs = cDays.map(d => get(d, s.corrX)), ys = cDays.map(d => get(d, s.corrY)); const r = pear(xs, ys);
    const rng = a => { if (!a.length) return [0, 1]; let lo = Math.min(...a), hi = Math.max(...a); if (hi === lo) { hi += 1; lo -= 1; } const p = (hi - lo) * 0.08; return [lo - p, hi + p]; };
    const [xl, xh] = rng(xs), [yl, yh] = rng(ys);
    const lab = k => CO.find(c => c[0] === k)[1];
    const ar = Math.abs(r);
    const corrText = s.corrX === s.corrY ? "Pick two different signals." : cDays.length < 3 ? "Not enough check-ins in this range yet." : (ar < 0.2 ? "No clear relationship" : (ar < 0.4 ? "Weak " : ar < 0.6 ? "Moderate " : "Strong ") + (r > 0 ? "positive" : "negative") + " relationship") + " between " + lab(s.corrX).toLowerCase() + " and " + lab(s.corrY).toLowerCase() + " across " + cDays.length + " days.";
    const corr = `<section class="card corr" aria-label="Correlation analysis">
      <div class="stack-14"><div><div class="kicker">Analysis</div><h2 class="corr-title">Correlate two signals</h2><p class="fs13 muted lh145 mt6">Daily check-ins and session logs over the selected range.</p></div>
        <label class="lbl">X axis<select class="field"${bind("corrX")}>${CO.map(([v, l]) => opt(v, l, s.corrX)).join("")}</select></label>
        <label class="lbl">Y axis<select class="field"${bind("corrY")}>${CO.map(([v, l]) => opt(v, l, s.corrY)).join("")}</select></label>
        <div class="corr-r"><div class="corr-num">r = ${cDays.length >= 3 ? r.toFixed(2) : "—"}</div><div class="fs13 lh14">${esc(corrText)}</div></div>
      </div>
      <div class="scatter">${cDays.map((d, i) => `<div class="sdot" title="${esc(sd(d) + ": " + xs[i] + ", " + ys[i])}" style="left:${((xs[i] - xl) / (xh - xl) * 100).toFixed(2)}%;top:${(100 - (ys[i] - yl) / (yh - yl) * 100).toFixed(2)}%"></div>`).join("")}<div class="sx">${esc(lab(s.corrX))} →</div><div class="sy">${esc(lab(s.corrY))} →</div></div>
    </section>`;

    return `${head}<div class="g-4">${kpis.map(statCard).join("")}</div><div class="g-hero">${loadCard}${consistency}</div><div class="g-3">${fingCard}${bodyCard}${wellCard}</div>${corr}`;
  }

  /* =========================================================
     Goals
     ========================================================= */
  function vGoals() {
    const s = S; const goalsI = s.goals.map(g => ({ g, i: gInfo(g, s.tests) }));
    const act = goalsI.filter(x => x.i.pct < 1);
    const head = pageHead("2026 season", "Goals", `<button type="button" class="btn primary"${on("newGoal")}>New goal</button>`);
    const sum = [{ l: "Active", v: String(act.length), c: "#2A211B" }, { l: "On track", v: String(act.filter(x => x.i.status === "On track").length), c: "#3F6B4F" }, { l: "Behind", v: String(act.filter(x => x.i.status !== "On track").length), c: "#B07A1E" }, { l: "Completed", v: String(goalsI.length - act.length), c: "#3E5A73" }];
    if (!goalsI.length) return `${head}<div class="g-4">${sum.map(statCard).join("")}</div><div class="card">${empty("Set a goal for the season: a grade, a strength number or a volume target.", "newGoal", "New goal")}</div>`;
    const cards = goalsI.map(({ g, i }) => `<div class="goal-card${g.id === s.selGoal ? " sel" : ""}"${tap("selGoal", g.id)}>
      <div class="row-between center"><span class="cat-chip" style="background:${GOAL_CC[g.cat] || "#8A7A6B"}">${esc(g.cat)}</span><span class="fs12 fw6" style="color:${i.sc}">${i.status}</span></div>
      <div class="goal-title">${esc(g.title)}</div>
      <div class="row-between baseline"><span class="goal-cur">${esc(i.fv(i.cur))}</span><span class="fs125 muted">target ${esc(i.fv(g.target))}</span></div>
      <div class="track"><div class="fill" style="width:${pct(i.pct * 100)};background:${i.sc}"></div><div class="pace" title="Expected by today" style="left:${pct(i.el * 100)}"></div></div>
      <div class="row-between fs12 muted"><span>${Math.round(i.pct * 100)}% complete</span><span>${esc(i.dl)}</span></div>
    </div>`).join("");
    const sel = goalsI.find(x => x.g.id === s.selGoal);
    let detail = "";
    if (sel) {
      const { g, i } = sel; const grade = g.cat === "Grade"; const lad = g.scale === "v" ? VG : YDS;
      const pts = [...(i.hist.length && i.hist[0].d > g.startD ? [{ d: g.startD, v: g.start }] : []), ...i.hist];
      const c = ser(pts.map(h => ({ d: h.d, v: h.v, lab: sd(h.d) + ": " + i.fv(h.v) })), { d0: g.startD, d1: g.deadline, lo: g.start, hi: g.target });
      const cc = GOAL_CC[g.cat] || "#8A7A6B";
      detail = `<aside class="card goal-detail stack-16" aria-label="Goal detail">
        <div class="row-between start gap10"><div><div class="kicker" style="color:${cc}">${esc(g.cat)} · ${i.status}</div><h2 class="detail-title">${esc(g.title)}</h2></div><button type="button" class="btn xs"${on("editGoal")}>Edit</button></div>
        ${g.note ? `<p class="focus-text">${esc(g.note)}</p>` : ""}
        ${miniStats([{ v: i.fv(g.start), l: "Start" }, { v: i.fv(i.cur), l: "Now" }, { v: sd(g.deadline), l: "Deadline" }], "big")}
        <div><div class="row-between fs115 muted mb6"><span>Progress vs. expected pace</span><span>Target ${esc(i.fv(g.target))}</span></div>
          <div class="chart axes" style="height:140px"><svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><polyline class="ln" style="stroke:#C9B8A3;stroke-width:1.5;stroke-dasharray:4 4" points="0,100 100,0"></polyline><polyline class="ln" style="stroke:${i.sc};stroke-width:2.5" points="${c.pts}"></polyline></svg>${c.dots.map(p => `<div class="cdot solid" title="${esc(p.lab)}" style="left:${p.l};top:${p.t};background:${i.sc}"></div>`).join("")}<div class="today-line" style="left:${pct(i.el * 100)}"></div><div class="axis-l">${sd(g.startD)}</div><div class="axis-r">${sd(g.deadline)}</div></div></div>
        ${i.t ? `<div class="linked"><span>Tracks the ${esc(i.t.name)} test.</span><button type="button" class="link"${on("testToPage", i.t.id)}>Log result →</button></div>`
          : `<div class="row gap8">${grade ? `<select class="field grow" aria-label="New grade"${bind("goalProg")}>${lad.map((l, k) => opt(k, l, s.goalProg === "" ? Math.round(i.cur) : s.goalProg)).join("")}</select>` : `<input class="field grow" type="number" step="any" inputmode="decimal" placeholder="New value (${esc(g.unit || "value")})" aria-label="New value" value="${esc(s.goalProg)}"${bind("goalProg")}>`}<button type="button" class="btn sm green"${on("updGoal")}>Update progress</button></div>`}
        <div class="divider stack-6"><div class="kicker mb4">Milestones</div>
          ${g.ms.map((m, k) => `<div class="ms${m.done ? " done" : ""}" role="checkbox" aria-checked="${m.done}" tabindex="0"${on("togMs", k)}><span class="ms-box" aria-hidden="true">${m.done ? "✓" : ""}</span><span>${esc(m.t)}</span></div>`).join("")}
          <div class="row gap6 mt4"><input class="field sm grow" placeholder="Add a milestone" aria-label="New milestone" value="${esc(s.newMs)}"${bind("newMs")} data-enter="addMs"><button type="button" class="btn xs"${on("addMs")}>Add</button></div>
        </div>
        <button type="button" class="link danger self-start"${on("delGoal")}>Delete goal</button>
      </aside>`;
    }
    return `${head}<div class="g-4">${sum.map(statCard).join("")}</div><div class="goal-layout"><div class="goal-cards">${cards}</div>${detail}</div>`;
  }

  /* =========================================================
     Tests
     ========================================================= */
  function vTests() {
    const s = S;
    const overdue = s.tests.filter(t => dueOf(t) < TODAY).length;
    const head = pageHead(s.tests.length + " protocols · " + (overdue ? overdue + " overdue" : "all current"), "Tests", `<button type="button" class="btn primary"${on("newT")}>New protocol</button>`);
    const list = s.tests.map(t => {
      const l = testLast(t), f = t.hist[0]; const due = dueOf(t) - TODAY; const ch = l && f && t.hist.length > 1 ? +(l.v - f.v).toFixed(1) : null;
      const dueTxt = !l ? "No results yet" : due < 0 ? "Overdue by " + (-due) + " d" : due === 0 ? "Due today" : "Next test in " + due + " d";
      return `<div class="list-card col${t.id === s.selTest ? " sel" : ""}"${tap("selTest", t.id)}>
        <div class="row-between gap10"><div><div class="list-name">${esc(t.name)}</div><div class="list-meta">${esc(t.cat)}</div></div><div class="right"><div class="test-val nowrap">${l ? esc(l.v + " " + t.unit) : "No results"}</div><div class="fs115 fw6" style="color:#3F6B4F">${ch != null ? (ch >= 0 ? "▲ " : "▼ ") + Math.abs(ch) + " since " + sd(f.d) : ""}</div></div></div>
        <div class="mono105 upper" style="color:${!l ? "#6E5F52" : due < 0 ? "#B5502A" : due <= 7 ? "#B07A1E" : "#6E5F52"}">${dueTxt}</div></div>`;
    }).join("") || `<div class="dashed-empty">No protocols yet.</div>`;
    const t = s.tests.find(x => x.id === s.selTest);
    let detail = "";
    if (t && s.testEdit && s.tDraft) {
      const d = s.tDraft;
      detail = `<section class="card test-detail stack-20" aria-label="Edit protocol">
        <div class="row-between center"><h2 class="sub-title">Edit protocol</h2><button type="button" class="btn xs danger"${on("delT")}>Delete protocol</button></div>
        <div class="g-21"><label class="lbl">Name<input class="field" value="${esc(d.name)}"${bind("tDraft.name")}></label><label class="lbl">Category<select class="field"${bind("tDraft.cat")}>${TEST_CATS.map(o => opt(o, o, d.cat)).join("")}</select></label></div>
        <div class="g-3i"><label class="lbl">Unit<input class="field" value="${esc(d.unit)}"${bind("tDraft.unit")}></label><label class="lbl">Better when<select class="field"${bind("tDraft.better")}>${opt("higher", "Higher", d.better)}${opt("lower", "Lower", d.better)}</select></label><label class="lbl">Retest every (weeks)<input class="field" type="number" min="1" value="${esc(d.freq)}"${bind("tDraft.freq")}></label></div>
        <label class="lbl">Equipment<input class="field" value="${esc(d.equip)}"${bind("tDraft.equip")}></label>
        <label class="lbl">Protocol steps (one per line)<textarea class="field lh15" rows="6"${bind("tDraft.steps")}>${esc(d.steps)}</textarea></label>
        <div class="row gap8 end"><button type="button" class="btn sm"${on("cancelT")}>Cancel</button><button type="button" class="btn sm primary"${on("saveT")}>Save protocol</button></div>
      </section>`;
    } else if (t) {
      const l = testLast(t), f = t.hist[0];
      const best = t.hist.length ? (t.better === "higher" ? Math.max(...t.hist.map(h => h.v)) : Math.min(...t.hist.map(h => h.v))) : null;
      const due = dueOf(t);
      const c = ser(t.hist.map(h => ({ d: h.d, v: h.v, lab: sd(h.d), val: String(h.v) })));
      const change = l && f && t.hist.length > 1 ? +(l.v - f.v).toFixed(1) : null;
      const xKeep = new Set(); let lastX = -99;
      c.dots.forEach((p, k) => { const x = parseFloat(p.l); if (x - lastX >= 15) { xKeep.add(k); lastX = x; } });
      if (c.dots.length > 1) { const lk = c.dots.length - 1, lx = parseFloat(c.dots[lk].l); if (!xKeep.has(lk)) { [...xKeep].forEach(k => { if (lx - parseFloat(c.dots[k].l) < 15) xKeep.delete(k); }); xKeep.add(lk); } }
      const improving = change == null ? true : (t.better === "lower" ? change <= 0 : change >= 0);
      detail = `<section class="card test-detail stack-20" aria-label="Test detail">
        <div class="row-between start gap12"><div><div class="kicker">${esc(t.cat)} · every ${t.freq} weeks</div><h2 class="detail-title lg">${esc(t.name)}</h2></div><button type="button" class="btn xs"${on("editT")}>Edit protocol</button></div>
        <div class="g-4i">${[{ l: "Latest", v: l ? l.v + " " + t.unit : "—" }, { l: "Best", v: best != null ? best + " " + t.unit : "—" }, { l: "Change", v: change != null ? (change >= 0 ? "+" : "") + change + " " + t.unit : "—", c: improving ? "#3F6B4F" : "#B5502A" }, { l: "Next due", v: !l ? "Now" : due < TODAY ? "Overdue" : sd(due), c: l && due < TODAY ? "#B5502A" : null }].map(x => `<div class="kpi-box"><div class="fs12 muted">${x.l}</div><div class="kpi-val"${x.c ? ` style="color:${x.c}"` : ""}>${esc(x.v)}</div></div>`).join("")}</div>
        <div class="test-grid">
          <div class="min0"><h3 class="h3">Results · ${esc(t.unit)}</h3>
            ${c.dots.length ? `<div class="chart tall" style="height:200px"><svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><polyline class="ln" style="stroke:#B5502A;stroke-width:2.5" points="${c.pts}"></polyline></svg>${c.dots.map((p, k) => `<div class="cdot ring lg" title="${esc(p.lab)}" style="left:${p.l};top:${p.t};border-color:#B5502A"></div><div class="clabel dark" style="left:${p.l};top:${p.t}">${esc(p.val)}</div>${xKeep.has(k) ? `<div class="xlabel" style="left:${p.l}">${esc(p.lab)}</div>` : ""}`).join("")}</div>` : `<div class="chart tall" style="height:200px">${chartMsg("No results yet. Log your first one below.")}</div>`}
            <div class="log-row"><input class="field sm" type="number" step="any" inputmode="decimal" placeholder="Result (${esc(t.unit)})" aria-label="Result in ${esc(t.unit)}" value="${esc(s.logVal)}"${bind("logVal")} data-enter="logT"><input class="field sm" type="date" aria-label="Date" value="${esc(s.logDate)}"${bind("logDate")}><input class="field sm note" placeholder="Note (optional)" aria-label="Note" value="${esc(s.logNote)}"${bind("logNote")} data-enter="logT"><button type="button" class="btn sm primary"${on("logT")}>Log result</button></div>
            <div class="mt14">${t.hist.map((h, i) => ({ h, i })).reverse().map(({ h, i }) => `<div class="res-row"><span class="mono12 muted">${sd(h.d)}</span><span class="fw7">${esc(h.v + " " + t.unit)}</span><span class="muted">${esc(h.note || "")}</span><button type="button" class="icon-btn sm"${on("delR", i)} aria-label="Delete result from ${sd(h.d)}">×</button></div>`).join("")}</div>
          </div>
          <div class="stack-14"><h3 class="h3">Protocol</h3>
            ${t.steps.length ? t.steps.map((x, i) => `<div class="step"><span class="step-n">${i + 1}</span><span>${esc(x)}</span></div>`).join("") : `<p class="empty-line">No steps yet. Edit the protocol to add them.</p>`}
            <div class="equip"><span class="kicker">Equipment</span><br>${esc(t.equip || "—")}</div>
            <button type="button" class="btn white xs"${on("planTest")}>Schedule on next due date · ${ld(clamp(Math.max(due, TODAY + 1), 0, DAYS - 1))}</button>
          </div>
        </div>
      </section>`;
    } else {
      detail = `<div class="card">${empty("Create a protocol to start tracking a benchmark.", "newT", "New protocol")}</div>`;
    }
    return `${head}<div class="test-layout"><div class="stack-10">${list}</div>${detail}</div>`;
  }

  /* =========================================================
     Modals
     ========================================================= */
  const modal = (inner, width = 520, label = "") => `<div class="overlay" data-on="closeModal" data-self="1"><div class="modal" role="dialog" aria-modal="true" aria-label="${esc(label)}" style="width:${width}px">${inner}</div></div>`;
  const closeX = `<button type="button" class="icon-btn lg"${on("closeModal")} aria-label="Close">×</button>`;
  function vModal() {
    const s = S, f = s.form;
    if (s.modal === "session") {
      const title = f.mode === "new" ? (f.status === "done" ? "Log session" : "Plan session") : (f.status === "done" ? "Log session" : "Edit session");
      const wOpts = [...s.workouts.map(w => [w.id, w.name]), ...(f.wid && !s.workouts.find(w => w.id === f.wid) ? [[f.wid, "(custom)"]] : []), ...(f.wid === "" ? [["", f.mode === "new" ? "Session" : "Test session"]] : [])];
      return modal(`<div class="row-between center"><h2 class="modal-title">${title}</h2>${closeX}</div>
        <div class="g-2"><label class="lbl">Workout<select class="field" data-oninput="setWid">${wOpts.map(([v, l]) => opt(v, l, f.wid)).join("")}</select></label><label class="lbl">Date<select class="field"${bind("form.day")}>${[...Array(DAYS)].map((_, d) => opt(d, ld(d) + (d === TODAY ? " (today)" : ""), f.day)).join("")}</select></label></div>
        ${seg([["Planned", "setStatus", "planned", f.status === "planned"], ["Done", "setStatus", "done", f.status === "done"], ["Skipped", "setStatus", "skipped", f.status === "skipped"]], "full")}
        <div class="g-2 end"><label class="lbl">Duration (min)<input class="field" type="number" min="0" inputmode="numeric" value="${esc(f.dur)}"${bind("form.dur")}></label><label class="lbl">Session RPE · ${esc(f.rpe)}<input type="range" min="1" max="10" value="${esc(f.rpe)}" class="range-pad"${bind("form.rpe")}></label></div>
        <label class="lbl">Location<input class="field" placeholder="e.g. Motherlode, home wall" value="${esc(f.loc)}"${bind("form.loc")}></label>
        <label class="lbl">Notes<textarea class="field" rows="2" placeholder="How did it go?"${bind("form.notes")}>${esc(f.notes)}</textarea></label>
        <div class="modal-foot"><span class="mono12 muted upper">Load ${fmtN((+f.dur || 0) * (+f.rpe || 0))} AU</span><div class="grow"></div>${f.mode === "edit" ? `<button type="button" class="btn sm danger"${on("delSession")}>Delete</button>` : ""}<button type="button" class="btn sm"${on("closeModal")}>Cancel</button><button type="button" class="btn sm primary"${on("saveSession")}>Save</button></div>`, 520, title);
    }
    if (s.modal === "check") {
      return modal(`<div><div class="kicker">${fullDate(TODAY)}</div><h2 class="modal-title mt4">Morning check-in</h2></div>
        ${[["mot", "Motivation", 1, 10, 1], ["sleep", "Sleep (hours)", 4, 10, 0.5], ["finger", "Finger feel", 1, 10, 1]].map(([k, l, mn, mx, st]) => `<label class="ck"><span class="row-between"><span class="fw6">${l}</span><span class="ck-val">${esc(f[k])}</span></span><input type="range" min="${mn}" max="${mx}" step="${st}" value="${esc(f[k])}"${bind("form." + k)}></label>`).join("")}
        <div class="row gap8 end"><button type="button" class="btn sm"${on("closeModal")}>Cancel</button><button type="button" class="btn sm green"${on("saveCheck")}>Save check-in</button></div>`, 420, "Morning check-in");
    }
    if (s.modal === "goal") {
      const grade = f.cat === "Grade"; const lad = f.scale === "v" ? VG : YDS;
      const title = f.mode === "new" ? "New goal" : "Edit goal";
      return modal(`<div class="row-between center"><h2 class="modal-title">${title}</h2>${closeX}</div>
        <label class="lbl">Goal<input class="field" placeholder="e.g. Redpoint 5.13a" value="${esc(f.title)}"${bind("form.title")}></label>
        ${seg(["Grade", "Strength", "Volume", "Habit"].map(c => [c, "goalCat", c, f.cat === c]), "full")}
        ${grade ? `<div class="g-3i"><label class="lbl">Scale<select class="field"${bind("form.scale")}>${opt("yds", "YDS (routes)", f.scale)}${opt("v", "V (boulders)", f.scale)}</select></label><label class="lbl">Current<select class="field"${bind("form.start")}>${lad.map((l, k) => opt(k, l, f.start)).join("")}</select></label><label class="lbl">Target<select class="field"${bind("form.target")}>${lad.map((l, k) => opt(k, l, f.target)).join("")}</select></label></div>`
          : `<div class="g-3i"><label class="lbl">Start<input class="field" type="number" step="any" value="${esc(f.start)}"${bind("form.start")}></label><label class="lbl">Target<input class="field" type="number" step="any" value="${esc(f.target)}"${bind("form.target")}></label><label class="lbl">Unit<input class="field" value="${esc(f.unit)}"${bind("form.unit")}></label></div>
          <label class="lbl">Track automatically from a test<select class="field"${bind("form.testId")}>${opt("", "No — update manually", f.testId)}${s.tests.map(t => opt(t.id, t.name + " (" + t.unit + ")", f.testId)).join("")}</select></label>`}
        <label class="lbl">Deadline<input class="field" type="date" value="${esc(f.deadline)}"${bind("form.deadline")}></label>
        <label class="lbl">Why it matters<textarea class="field" rows="2"${bind("form.note")}>${esc(f.note)}</textarea></label>
        <div class="modal-foot end"><button type="button" class="btn sm"${on("closeModal")}>Cancel</button><button type="button" class="btn sm primary"${on("saveGoal")}>Save goal</button></div>`, 520, title);
    }
    if (s.modal === "accounts") {
      const n = accounts.list.length;
      return modal(`<div class="row-between center"><div><div class="kicker">${n} ${n === 1 ? "account" : "accounts"}</div><h2 class="modal-title mt4">Who's training?</h2></div>${closeX}</div>
        <div class="acct-list">${accounts.list.map(a => { const cur = a.id === accounts.currentId; return `<button type="button" class="acct${cur ? " cur" : ""}"${on("switchAccount", a.id)}><span class="avatar" style="background:${esc(a.color || AVATARS[0])}">${esc(initials(a.name))}</span><span class="grow"><span class="acct-name">${esc(a.name)}</span><span class="acct-sub">${esc([a.role, a.home].filter(Boolean).join(" · ") || "Climber")}</span></span><span class="acct-flag">${cur ? "Active" : "Switch"}</span></button>`; }).join("")}</div>
        <div class="row gap8 wrap"><button type="button" class="btn sm"${on("newAccount")}>+ Add person</button><button type="button" class="btn sm"${on("editAccount")}>Edit active profile</button></div>
        <p class="fs12 muted lh145">Each person has their own plan, sessions, goals, tests and check-ins, saved separately in this browser. Profiles aren't password protected: anyone using this browser can switch between them.</p>`, 460, "Who's training?");
    }
    if (s.modal === "account") {
      const isNew = f.mode === "new"; const title = isNew ? "Add a person" : "Edit profile";
      return modal(`<div class="row-between center"><h2 class="modal-title">${title}</h2>${closeX}</div>
        <label class="lbl">Name<input class="field" placeholder="e.g. Jordan Reyes" value="${esc(f.name)}"${bind("form.name")} data-enter="saveAccount"></label>
        <div class="g-2"><label class="lbl">Coaching<input class="field" placeholder="Self-coached, or coach name" value="${esc(f.role)}"${bind("form.role")}></label><label class="lbl">Home crag or gym<input class="field" placeholder="e.g. Red River Gorge" value="${esc(f.home)}"${bind("form.home")}></label></div>
        <label class="lbl">Bodyweight (kg)<input class="field" type="number" step="0.1" inputmode="decimal" value="${esc(f.weight)}"${bind("form.weight")}><span class="help">Shown until you log a body measurement on the Metrics page.</span></label>
        ${isNew ? `<div class="lbl">Start with<div class="start-opts">${[["blank", "A blank slate", "Workout library and test protocols, no history."], ["sample", "The sample cycle", "A copy of the 12-week fall plan with example data."]].map(([k, t, d]) => `<button type="button" class="start-opt${f.start === k ? " on" : ""}" aria-pressed="${f.start === k}"${on("acctStart", k)}><span class="fw6">${t}</span><span class="fs12 muted">${d}</span></button>`).join("")}</div></div>` : ""}
        <div class="modal-foot">${!isNew && accounts.list.length > 1 ? `<button type="button" class="btn sm danger${s.armed ? " armed" : ""}"${on("deleteAccount")}>${s.armed ? "Delete " + esc(firstName(f.name)) + " and all data?" : "Delete account"}</button>` : ""}<div class="grow"></div><button type="button" class="btn sm"${on(isNew ? "closeModal" : "openAccounts")}>Cancel</button><button type="button" class="btn sm primary"${on("saveAccount")}>${isNew ? "Create account" : "Save profile"}</button></div>`, 520, title);
    }
    return "";
  }

  /* =========================================================
     Render: build HTML, then patch the live DOM in place so
     inputs keep focus and caret while state changes.
     ========================================================= */
  const VIEWS = { dashboard: vDashboard, planner: vPlanner, workouts: vWorkouts, metrics: vMetrics, goals: vGoals, tests: vTests };
  function view() {
    const c = vChrome();
    return `<div class="shell">${c.side}<div class="main-col">${c.top}<main class="main" id="main">${(VIEWS[S.page] || vDashboard)()}</main></div></div>${c.tabs}${vModal()}`;
  }
  function patch(from, to) {
    if (from.nodeType === 1) {
      for (let i = from.attributes.length - 1; i >= 0; i--) { const n = from.attributes[i].name; if (!to.hasAttribute(n)) from.removeAttribute(n); }
      for (const a of to.attributes) if (from.getAttribute(a.name) !== a.value) from.setAttribute(a.name, a.value);
      const tag = from.tagName;
      if (tag === "INPUT") { const v = to.getAttribute("value") ?? ""; if (from.value !== v && document.activeElement !== from) from.value = v; return; }
      if (tag === "TEXTAREA") { const v = to.textContent; if (from.value !== v && document.activeElement !== from) from.value = v; return; }
      if (tag === "SELECT") {
        const sel = to.querySelector("option[selected]"); const want = sel ? sel.getAttribute("value") : null;
        patchChildren(from, to);
        if (want != null && from.value !== want) from.value = want;
        return;
      }
    }
    patchChildren(from, to);
  }
  function patchChildren(from, to) {
    const fc = Array.from(from.childNodes), tc = Array.from(to.childNodes);
    for (let i = 0; i < tc.length; i++) {
      const t = tc[i], f = fc[i];
      if (!f) { from.appendChild(t); continue; }
      if (f.nodeType !== t.nodeType || f.nodeName !== t.nodeName) { from.replaceChild(t, f); continue; }
      if (f.nodeType === 3 || f.nodeType === 8) { if (f.nodeValue !== t.nodeValue) f.nodeValue = t.nodeValue; continue; }
      patch(f, t);
    }
    for (let i = fc.length - 1; i >= tc.length; i--) from.removeChild(fc[i]);
  }
  const root = document.getElementById("app");
  let lastModal = null, pendingReveal = null, lastStripKey = "";
  const reduceMotion = () => window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  // On single-column layouts the detail panel sits below the list; bring it into view after a pick.
  const reveal = sel => { pendingReveal = sel; };
  function afterRender() {
    if (pendingReveal) {
      const el = root.querySelector(pendingReveal); pendingReveal = null;
      if (el && window.matchMedia("(max-width: 1060px)").matches) el.scrollIntoView({ behavior: reduceMotion() ? "auto" : "smooth", block: "start" });
    }
    const key = S.page + ":" + S.weekSel;
    if (S.page === "planner" && key !== lastStripKey) {
      const cell = root.querySelector(".week-cell.sel"), sc = cell && cell.closest(".scroll-x");
      if (sc && sc.scrollWidth > sc.clientWidth) sc.scrollLeft = cell.offsetLeft - sc.offsetLeft - sc.clientWidth / 2 + cell.offsetWidth / 2;
    }
    lastStripKey = key;
  }
  // Removing a focused field fires blur/change mid-patch; queue that render instead of nesting it.
  let rendering = false, renderAgain = false;
  function render() {
    if (rendering) { renderAgain = true; return; }
    rendering = true;
    try {
      const tpl = document.createElement("template");
      tpl.innerHTML = view();
      patchChildren(root, tpl.content);
    } finally { rendering = false; }
    if (renderAgain) { renderAgain = false; return render(); }
    afterRender();
    document.title = (S.page === "dashboard" ? "" : S.page[0].toUpperCase() + S.page.slice(1) + " · ") + "Pocket Training";
    if (S.modal !== lastModal) {
      if (S.modal) {
        const m = root.querySelector(".modal");
        const first = m && m.querySelector("input:not([type=range]),select,textarea,button:not(.icon-btn)");
        if (first) first.focus({ preventScroll: true });
        document.body.classList.add("modal-open");
      } else document.body.classList.remove("modal-open");
      lastModal = S.modal;
    }
  }

  /* =========================================================
     Events
     ========================================================= */
  function run(name, arg) { const fn = actions[name]; if (fn) fn(arg); }
  document.addEventListener("click", e => {
    const t = e.target.closest("[data-on]");
    if (!t || !root.contains(t)) return;
    if (t.dataset.self && e.target !== t) return;
    if (t.disabled) return;
    run(t.dataset.on, t.dataset.arg);
  });
  document.addEventListener("keydown", e => {
    if (e.key === "Escape" && S.modal) { e.preventDefault(); return actions.closeModal(); }
    const t = e.target;
    if ((e.key === "Enter" || e.key === " ") && t.matches && t.matches('[role="button"][data-on],[role="checkbox"][data-on]')) { e.preventDefault(); return run(t.dataset.on, t.dataset.arg); }
    if (e.key === "Enter" && t.dataset && t.dataset.enter) { e.preventDefault(); run(t.dataset.enter); }
  });
  const onField = e => {
    const t = e.target; if (!t.dataset) return;
    if (t.dataset.bind) { if (String(getPath(t.dataset.bind)) !== t.value) setPath(t.dataset.bind, t.value); }
    else if (t.dataset.oninput) run(t.dataset.oninput, t.value);
  };
  const getPath = path => path.split(".").reduce((o, k) => (o == null ? o : o[k]), S);
  document.addEventListener("input", onField);
  document.addEventListener("change", onField);
  window.addEventListener("hashchange", () => { const p = pageFromHash(); if (p && p !== S.page) { set({ page: p, modal: null }); window.scrollTo(0, 0); } });
  window.addEventListener("pagehide", () => { if (saveTimer) persistNow(); });
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "hidden" && saveTimer) persistNow(); });

  render();
  ensureCurrentFormat();
})();
